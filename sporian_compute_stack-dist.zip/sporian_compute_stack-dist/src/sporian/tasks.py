import os
import time
import redis
import pickle
from celery.utils.log import get_task_logger
from compute_node.celery import app, redis_task_lock
from sporian.models import Scan
from sporian.sensor_reader import HsioMemoryBuffer
from django.utils import timezone
from django.conf import settings
from django.db import transaction
from concurrent.futures import ThreadPoolExecutor
from django.core.cache import cache

logger = get_task_logger(f"compute_node.{__name__}")


@app.task(bind=True, soft_timeout=30*60)
def read_sensor(self, address=os.environ['SENSOR_ADDR'], lock_id="read_sensor"):
    with redis_task_lock(lock_id, self.request.id) as acquired:
        if not acquired:
            logger.error("Cannot run parallel collections")
            return
        logger.info("Obtained lock, running collection")

        hsio_membuff = HsioMemoryBuffer(address)
        hsio_membuff.run_loop(lock_id)
    del(hsio_membuff)


@app.task(bind=True, soft_timeout=30*60)
def parse_scans(self, lock_id="parse_scans"):
    from drone.models import Mission
    latest_mission = Mission.objects.latest('pk')
    last_scan_id = 0
    redis_client = redis.StrictRedis(
        host=os.environ["REDIS_HOST"],
        port=os.environ["REDIS_PORT"], db=3
    )
    scan_store_base = os.path.join(
        settings.SCAN_STORE_DIR, f"mission.{latest_mission.pk}")
    os.makedirs(scan_store_base, exist_ok=True)

    last_scanNum = 0
    max_scan_id = 5000
    check_counter = 0
    with redis_task_lock(lock_id, self.request.id) as acquired:
        while True:
            # Check if we need to break while loop
            check_counter += 1
            if check_counter > 100:
                check_counter = 0
                if not cache.get(lock_id):
                    raise ConnectionAbortedError("Exiting collection")

            latest_scan_id = redis_client.get("latest_scan")
            logger.info(f"Latest Scan ID: {latest_scan_id}")
            if latest_scan_id is None:
                time.sleep(0.1)
                continue
            
            # Wait if no new scans or get the full range of scan IDs from Cache
            latest_scan_id = int(latest_scan_id)
            if latest_scan_id == last_scan_id:
                time.sleep(0.1)
                continue
            elif latest_scan_id > last_scan_id:
                scan_ids = list(range(last_scan_id, latest_scan_id))
            else: # We wrapped around max_scan_id
                scan_ids = list(range(last_scan_id, max_scan_id)) + \
                    list(range(0, latest_scan_id))
            
            # Fetch all scans from cache
            scan_data_block = redis_client.mget([
                f"scan.{scan_id}"
                for scan_id in scan_ids
            ])
            logger.info(f"Retrieved Scan datablock: {len(scan_data_block)}")
            if not scan_data_block:
                time.sleep(0.05)
                continue

            last_scan_id = latest_scan_id
            # Write the scan block to disk
            scan_data_file = os.path.join(
                scan_store_base, f"scans.{last_scanNum}.pkl"
            )
            # Write the serialized data to a file
            with open(scan_data_file, 'wb') as f:
                f.write(pickle.dumps(scan_data_block))
            logger.info(f"Saved full Scan datablock: {scan_data_file}")

            relative_time = timezone.now() - latest_mission.timestamp
            def create_model_instance(scan):
                return Scan.from_binary(
                    scan, latest_mission, relative_time.total_seconds()
                )
            with ThreadPoolExecutor() as executor:
                scans = list(
                    executor.map(
                        create_model_instance, scan_data_block[::settings.SCAN_PARSE_INTERVAL]
                    )
                )
            logger.info(
                f"Parsed sparse scans (Scan count: {len(scans)} of {len(scan_data_block)})"
            )
            
            last_scanNum = scans[-1].scanNum
            start_save = timezone.now()
            with transaction.atomic():
                Scan.objects.bulk_create(scans, batch_size=500, ignore_conflicts=True)
            total_time = (timezone.now() - start_save).total_seconds()
            logger.info(f"Bulk created scan {len(scans)} records [T:{total_time*1000}ms]"
                        f" Start/End {scans[0].scanNum}/{scans[-1].scanNum}")
            
