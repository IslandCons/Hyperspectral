import numpy as np
import pandas as pd
import logging
import plotly.express as px
import plotly.graph_objects as go

logger = logging.getLogger("compute_node.%s" % __name__)


def convert_galvo_ang(galvo):
    return (2.9043E-04 * galvo) - 11.36628

def color_image_df(scan_list, ri=(64,93), gi=(55,73), bi=(29,41)):
    # Save the material dictionary to disk
    df = []
    for scan in scan_list:
        vis_data = np.array(list(scan.vis_data))
        vis_data = (((vis_data - min(vis_data)) / (max(vis_data) - min(vis_data))) * 255).astype(np.uint8)
        r, g, b = np.mean(vis_data[ri[0]:ri[1]]), np.mean(vis_data[gi[0]:gi[1]]), np.mean(vis_data[bi[0]:bi[1]])
        df.append({
            "scanNum": scan.scanNum, 
            "max_vis": int(max(scan.vis_data)),
            "timestamp": scan.timeStamp,
            "galvo_pos": scan.galvoPos,
            "color_r": r + (255 - r)*0.3,
            "color_g": g + (255 - g)*0.4,
            "color_b": b + (255 - b)*0.4,
            "text": f"{scan.scanNum} G-{scan.galvoPos} T-{scan.timeStamp}"

        })
    df = pd.DataFrame(df)

    df['galvo_pos'] = convert_galvo_ang(df['galvo_pos'])
    df.color_r = df.color_r.astype(np.uint8)
    df.color_g = df.color_g.astype(np.uint8)
    df.color_b = df.color_b.astype(np.uint8)
    df["color"] = "rgb(" + df["color_r"].astype(str) + "," + df["color_g"].astype(str) + "," + df["color_b"].astype(str) + ")"
    return df


def get_color_df(cdf, samples=5*10**4, size=10, opacity=0.7):
    if samples and samples < len(cdf):
        df = cdf.sample(samples)
    else:
        df = cdf
    trace = go.Scattergl(
        x=df.galvo_pos, y=df.timestamp, 
        mode='markers',
        hoverinfo='text',
        hovertext=df.text,
        marker=dict(
            size=size,
            color=df.color.values,
            opacity=opacity,
        ),
    )

    data = [trace]
    layout = go.Layout(margin=dict(l=0, r=0, b=0, t=0))
    fig = go.Figure(data=data, layout=layout)
    fig.update_layout(
        width=800, height=800, 
        xaxis=dict(),
        yaxis=dict(autorange="reversed"),
    )
    # fig.show()
    return fig


def add_material_annot(fig, materials):
    from sporian.models import Scan
    for material in materials:
        scan_start = Scan.objects.get(scanNum=material.scanNum_start)
        scan_end = Scan.objects.get(scanNum=material.scanNum_end)
        # Draw a box using the two points
        fig.add_shape(type="rect",
            x0=convert_galvo_ang(material.galvo_start), y0=scan_start.timeStamp,
            x1=convert_galvo_ang(material.galvo_end), y1=scan_end.timeStamp,
            line=dict(color="green", width=2),
        )

        # Add text annotation to the box
        fig.add_annotation(
            x=(
                convert_galvo_ang(material.galvo_start) + 
                convert_galvo_ang(material.galvo_end)) / 2,
            y=(scan_start.timeStamp + scan_end.timeStamp) / 2,
            text=f"{material.pk} {material.material_id}",
            showarrow=False,
            font=dict(color="green", size=12)
        )
    return fig


def create_scan_map(scan_instances, materials):
    cdf = color_image_df(scan_instances)
    fig = get_color_df(cdf)
    fig = add_material_annot(fig, materials)
    return fig



def create_scan_sweep(cdf, size=10, opacity=0.7):
    trace = go.Bar(
        x=cdf['galvo_pos'],  # X-axis data
        y=cdf['max_vis'],    # Using DataFrame index for Y-axis (each row gets a bar)
        orientation='v',    # Horizontal orientation for bars
        marker=dict(
            line=dict(
                width=size, color=cdf.color.values
            ),
            color=cdf.color.values,
            opacity=opacity,
        ),
    )

    layout = go.Layout(
        title='Galvo Bar Chart',
        xaxis=dict(title='Galvo Position'),
    )
    # Create figure
    fig = go.Figure(data=[trace], layout=layout)
    fig.update_layout(
        barmode="stack",
        bargap=0, 
        width=1200, height=800, 
        xaxis=dict(),
        yaxis=dict(),
    )
    return fig


