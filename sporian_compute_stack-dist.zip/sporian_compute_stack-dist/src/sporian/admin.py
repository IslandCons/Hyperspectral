import logging
from django.contrib import admin
from .models import Scan
from django.db.models import Max, Min
from analysis import tasks as ana_tasks

logger = logging.getLogger(f"compute_node.{__name__}")


@admin.register(Scan)
class ScanAdmin(admin.ModelAdmin):
    list_display = ("scanNum", "mission", "relative_time", "timeStamp")
    actions = ("ana_range", "ana_select")
    list_filter = ['mission',]

    @admin.action(description='Analyze Range')
    def ana_range(modeladmin, request, queryset):
        aggs = queryset.aggregate(
            Max('scanNum'), Min('scanNum')
        )
        min_sn = aggs['scanNum__min']
        max_sn = aggs['scanNum__max']
        logger.info(f"Analyzing range of Scans from {min_sn} to {max_sn}")
        res = ana_tasks.classify_range.apply_async(
            kwargs={"start_scan": min_sn, "end_scan": max_sn},
            queue="global"
        )
        logger.info(f"Task created: {res}")

    @admin.action(description='Analyze Selected')
    def ana_select(modeladmin, request, queryset):
        pass
