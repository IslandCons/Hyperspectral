#!/usr/bin/python3
"""
Copyright (C) 2019, Sporian Microsystems, Inc.
All Rights Reserved.

This document is the proprietary and confidential property of Sporian
Microsystems, Inc ("Sporian").  All use, distribution, reproduction or
re-distribution is disallowed without the prior written consent of Sporian
Microsystems, Inc.
"""

import socket
import struct
from threading import Lock

DEFAULT_IP, DEFAULT_PORT = "10.11.12.2", 4000

class TcpsioError(Exception):
    def __init__(self, message, origErr=None):
        self.message = message
        self.origErr = origErr

class tcpsio:
    """ Programmatically communicate with devices which implement a TCP based
    command line interface.

    Such devices receive a command line, return the response from the command
    line, then send the device prompt and again wait to receive another command
    line.

    We presume that devices expect lines it receives to be terminated by '\n',
    however many Sporian devices including HSI devices, work with lines
    terminated also by a single '\r' or the '\r\n' character pair.  Use '\n' as
    this is the preferred end of line sequence and the one used by HSI devices
    to terminate lines it outputs.
    """
    def __init__(self, ip=DEFAULT_IP, port=DEFAULT_PORT, prompt=None):
        self.lock = Lock()
        self.device = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.device.settimeout(5)
        self.device.connect((ip, port))
        self.prompt = self._autoprompt() if prompt is None else prompt

    def _autoprompt(self):
        """ Determine the prompt string of the connected device.
        This works by sending LF twice.  While the result from the first LF
        could include prior data in the device's input stream, the second one
        will only include the device's prompt.
        """
        def crlfread(conn):
            conn.send(b'\n')
            msg = None
            while not msg:
                msg = conn.recv(1024 * 10)
            return msg

        try:
            with self.lock:
                crlfread(self.device)
                return crlfread(self.device)
        except (socket.timeout, socket.error) as e:
            raise TcpsioError(str(e), origErr=e)

    def abort(self, data=b' '):
        """ Some commands on the device run until the connected host sends some
        data.  Use this command to send that data.
        """
        if isinstance(data, str):
            data = data.encode('utf-8')
        self.device.send(data)

    def cmd(self, command, binaryArg=None):
        """ Send a command to the device and return its response.
        Args:
            command(str): The device command.
            binaryArg(bytes): Optional binary argument.  Used by few commands.
        Returns:
            bytes: The response from the device up to but not including the
                device prompt it writes after the command response data.
        Raises:
            TcpsioError: on socket timeout or error
        """
        try:
            with self.lock:
                if binaryArg:
                    self.device.send(command.encode() + b'\n' + binaryArg)
                else:
                    self.device.send(command.encode() + b'\n')

                nprompt = len(self.prompt)
                msg = bytearray()
                while True:
                    msg.extend(self.device.recv(1024 * 10))
                    # the prompt check assumes that the prompt is the last
                    # thing to be sent. nothing should be send after it
                    if len(msg) >= nprompt:
                        if self.prompt in msg[-nprompt:]:
                            return bytes(msg[:-nprompt])
        except (socket.timeout, socket.error) as e:
            raise TcpsioError(str(e), origErr=e)

    def bindata(self, command, lenfmt):
        """ Send a command and retrieve binary data blocks via generator.
        Args:
            command(str): The device command.  The command must be one that
                returns zero or more binary data blocks in response.
            lenfmt(str):  The struct format of the first field in each binary
                data block which contains the length of said block.
        Yields:
            bytes: The binary block data
        Raises:
            TcpsioError: on socket timeout or error

        This function is a generator that yields binary blocks of data received
        from the device after sending it the supplied command.  The device will
        emit zero or more blocks of binary data before sending the prompt.  The
        device prompt is that marker that denotes the end of data blocks.

        Each block of binary data must have as its first few bytes its length
        in network byte order according to the format specified in `lenfmt`.
        The size includes the length bytes.
        """
        def firstRecv(s, nbytes):
            """ Receive `nbytes` from socket `s` unless `s` has closed
            or the device prompt is received in <= `nbytes`.

            Args:
                s(socket): The socket from which to read.
                nbytes(int): The maximum number of bytes to read.
            Returns:
                bytes: The return value is b'' if the socket has closed or the
                    device prompt is received.  Otherwise, return `bytes` bytes
                    of data read from the device.
            """
            data = bytearray()
            dlen = 0
            while dlen < nbytes:
                newdata = s.recv(nbytes - dlen)
                newlen = len(newdata)
                if newlen == 0:
                    print(':bindata socket closed')
                    return b'' # socket has closed
                data.extend(newdata)
                if data == self.prompt:
                    return b'' # prompt received, normal termination
                dlen += newlen
            return data

        lensize = struct.calcsize(lenfmt)
        nbytes = max(lensize, len(self.prompt))
        try:
            with self.lock:
                self.device.send(command.encode() + b'\n')
                while True:
                    binary = firstRecv(self.device, nbytes)
                    binlen = len(binary)
                    if binlen == 0:
                        return # socket has closed or prompt received
                    else:
                        scanLen = struct.unpack(lenfmt, binary[:lensize])[0]
                        while binlen < scanLen:
                            newbytes = self.device.recv(scanLen - binlen)
                            newlen = len(newbytes)
                            if newlen == 0:
                                return # socket closed, last block incomplete
                            binary.extend(newbytes)
                            binlen += newlen
                        yield binary
        except (socket.timeout, socket.error) as e:
            raise TcpsioError(str(e), origErr=e)

    def cmdlns(self, command):
        """ Send a command to the device, returning a list of strings.
        Args:
            command(str): The command to send
        Returns:
            list(str): A list of strings.  Each string contains one line of
                output sent by the device.  Lines are terminated by '\n'.
        Raises:
            TcpsioError: on socket timeout or error

        This function throws out the last string which should be an empty line.
        """
        ret = self.cmd(command)
        return [ s.decode() for s in ret.split(b'\n')[:-1]]

    def finish(self):
        """ Close the connection to the device """
        self.device.close()
