"""
Copyright (C) 2019-2022, Sporian Microsystems, Inc.
All Rights Reserved.

This document is the proprietary and confidential property of Sporian
Microsystems, Inc ("Sporian").  All use, distribution, reproduction or
re-distribution is disallowed without the prior written consent of Sporian
Microsystems, Inc.
"""

"""
Operations with a 2022 Hyperspectral Imager (HSI).  This code will not work
with pre-2022 HSI devices as their data format differs.  See
ssh://proj.sporian.com:29418/lpc/hyper.git:py/hsio.py for a version of this
code suitable for pre-2022 HSI devices.
"""

import os
import sys
from datetime import datetime
import json
import numpy as np

import matplotlib
matplotlib.use('TkAgg')

import matplotlib.pyplot as plt
#from matplotlib.animation import FuncAnimation

from hsio import Scan, HSIo
hsi = None # Global for plotting; see on_close()

def usage(errorMessage=None):
    usage = \
"""
usage: python3 hsiops.py [options] [command args]
    Interact with the hyperspectral device, or with hyperspectral data.
    Commands which communicate with the hyperspectral device must provide
    the device's IP address using the "-ip" option
Options:
    -ip <IP[:port]>: Required for networked commands.
        IP: The device IP address or hostname.
        port: The default port (4000) is used if no port is provided.
    -f <script>: Read commands to run from a file named <script>.  The file
        must have one command per line.
Networked Commands:
    scan <output_dir>: Take a scan and write it to a file in output dir
    scans <output_dir> [n [fname]]: Take n scans and write them to a file in
        the output_dir.
        - If n is not provided, get scans and write until interrupted.
        - If fname is not provided, it is derived from the first scan number.
          If fname is provided, '.smhs' is automatically added.
    sweep <pause|resume>: Turn on or off galvo sweeping.
    livemeta: Get live scans from a device and print the meta string.
        The scan is not saved to file.
    verify_scans: Read scans from a device, reporting missed scans.
    view: Read scans from device, plotting pixel band data @ ~ 10 Hz.
    view_ir: Read scans from device, plotting IR pixel band data @ ~ 10 Hz.
    view_vis: Read scans from device, plotting vis pixel band data @ ~ 10 Hz.
    view_sweep: Capture scan sets (sweep sets) from a device, plotting the
        visible pixel band data in a 3D plot.
    view_galvo [nscans]: Show the as-read galvo position from live scans.  The
        default number of scans per plot update (nscans) is 4000.
Non-networked commands:
    shell <cmd>: Execute <cmd> as a local OS shell command.  Useful when
        creating scripts of commands (see -f above).
    meta <filename>: Print the meta data from all scans in the named file.
    verify_file: Read scans from a file, reporting missed scans.
    tocsv <binfile> <csvfile>: Convert binfile containing binary data into CSV
        written to csvfile.
"""
#uvitime <itime> [-ms]: Set the uv itime in milliseconds of float value
#iritime <itime> [-ms]: Set the ir itime in milliseconds of float value
    if errorMessage is not None:
        print("ERROR:  " + errorMessage)
    print(usage)
    sys.exit(-1)


def scanToFile(hsi, folder):
    """ Read one scan and write it to a disk file.
    Args:
        hsi(HSIo): Connected to an HSI device.
    Returns:
        str: The filename containing the read scan.
    """
    scan = hsi.getscan()
    fname = folder + '/' + str(scan.scanNum) + '.smhs'
    with open(fname, 'wb') as file:
        file.write(scan.binary)
    return fname


def scansToFile(hsi, folder, count=None, fname='', device=None):
    """ Read scans and write them to a disk file.
    Args:
        hsi(HSIo): Connection to an HSI device.
        folder(str): The directory into which to place the scan file.
        count(int): The number of scans to write, or None to run until
            interrupted (KeyboardInterrupt).

    Returns:
        filename: The filename where the scans were written.
        count: The count of scans placed into the file.
        missed: The number of missed scanNum values (dropped scans).
    """
    nscans = 0
    missed = 0
    try:
        scans = hsi.bindata('scans', device)

        # Read first Scan to get its scanNum to construct the output filename
        scandata = next(scans, b'')
        if scandata == b'':
            print('No scans!')
            return '', 0, 0 # No scans provided by the HSI device
        scan = Scan(scandata)

        if fname[-5:] == '.smhs':
            fname = fname[:-5]
        if fname:
            fname = f'{folder}/{fname}.smhs'
        else:
            fname = f'{folder}/{scan.scanNum}.smhs'
        prevScan = scan.scanNum

        # Write out all scan data to the file
        with open(fname, 'wb') as file:
            for scandata in scans:
                file.write(scandata)
                scan = Scan(scandata)
                nscans += 1
                if count is not None and nscans == count:
                    break
                if nscans % 1000 == 0:
                    print(f'\r{nscans}        ', end='')
                delta = scan.scanNum - (prevScan + 1)
                if delta != 0:
                    print(f'\nmissed {delta} scans: '
                          f'{prevScan} -> {scan.scanNum}')
                    missed += delta
                prevScan = scan.scanNum
    except KeyboardInterrupt:
        hsi.abort()
        print('\nKeyboard interrupt')
    return fname, nscans, missed


def on_close(event):
    global hsi
    if hsi:
        hsi.abort()
        hsi = None


def plot_both():
    global hsi

    rescale = True
    plotStyle = '.'
    def on_key(event):
        if event.key == 'r':
            nonlocal rescale
            rescale = True
        elif event.key == 'p':
            nonlocal plotStyle
            if plotStyle == '.':
                plotStyle = 'o'
            elif plotStyle == 'o':
                plotStyle = '-'
            else:
                plotStyle = '.'

    fig, ax = plt.subplots()
    fig.canvas.mpl_connect('close_event', on_close)
    fig.canvas.mpl_connect('key_press_event', on_key)
    ax2 = ax.twinx()
    while hsi:
        if rescale:
            rescale = False
            ylmin = yl2min = 65536
            ylmax = yl2max = 0

        scan = hsi.getscan()
        vis = scan.sensorData.visData[:-8]
        nvis = len(vis)
        ir = scan.sensorData.irData
        nir = len(ir)

        ax.clear()
        ax.plot(list(range(nvis)), vis, plotStyle, color='blue')
        ylmin = min(min(vis), ylmin)
        ylmax = max(max(vis), ylmax)
        ax.set_ylim([ylmin, ylmax])

        ax2.clear()
        ax2.plot(list(range(nvis, nvis + nir)), ir, plotStyle, color='red')
        yl2min = min(min(ir), yl2min)
        yl2max = max(max(ir), yl2max)
        ax2.set_ylim([yl2min, yl2max])

        plt.show(block=False)
        plt.pause(0.1)


def plot(ir):
    global hsi

    rescale = True
    plotStyle = '.'
    def on_key(event):
        if event.key == 'r':
            nonlocal rescale
            rescale = True
        elif event.key == 'p':
            nonlocal plotStyle
            if plotStyle == '.':
                plotStyle = 'o'
            elif plotStyle == 'o':
                plotStyle = '-'
            else:
                plotStyle = '.'

    fig, ax = plt.subplots()
    fig.canvas.mpl_connect('close_event', on_close)
    fig.canvas.mpl_connect('key_press_event', on_key)
    while hsi:
        if rescale:
            rescale = False
            ylmin = 65536
            ylmax = 0

        ax.clear()
        scan = hsi.getscan()
        if ir:
            data = scan.sensorData.irData
            color = 'red'
        else:
            data = scan.sensorData.visData[:-8]
            color = 'blue'
        ax.plot(list(range(len(data))), data, plotStyle, color=color)

        ylmin = min(min(data), ylmin)
        ylmax = max(max(data), ylmax)
        ax.set_ylim([ylmin, ylmax])
        plt.show(block=False)
        plt.pause(0.1)


def adjacent_scans(hsi):
    """
    Return two adjacent Scans that have different galvo positions and are
    adjacent as identified by seqNum.
    """
    scans = hsi.bindata('scan 100')
    s1 = Scan(next(scans, b''))
    for s2 in scans:
        s2 = Scan(s2)
        if s1.sensorData.galvoPos != s2.sensorData.galvoPos and \
                (s1.sensorData.seqNum + 1) & 0xffff == s2.sensorData.seqNum:
            for tmp in scans:
                pass
            return s1, s2
        s1 = s2
        s2 = None
    print(':adjacent_scans: device is not responding')
    return None, None


def sweep(hsi, galvoP1, galvoP2, step):
    """ Acquire a set of scans representing one sweep of the galvo.
    Returns a list of Scans.
    """
    endCount = 6 # Number of scans taken at each galvo endpoint
    nscans = 1000 #FIXME: not a good strategy

    # Windows systems appear to be sensitive to the amount of work done while
    # capturing scans.  So, capture scans first and do all the work after.
    raw_scans = hsi.bindata(f'scan {2 * (nscans + endCount)}')
    scans = [Scan(s) for s in raw_scans]

    # Find the min and max galvo positions in the data set
    gmin = min([s.sensorData.galvoPos for s in scans])
    gmax = max([s.sensorData.galvoPos for s in scans])

    # Find the first full sweep in scans[]
    state = 0 # 0:looking for first, 1:skipping first dupes, 2:found !first
    for i, s in enumerate(scans):
        if state == 0:
            if s.sensorData.galvoPos in (gmin, gmax):
                first = i
                state = 1
                otherEnd = gmax if s.sensorData.galvoPos == gmin else gmin
        elif state == 1:
            if s.sensorData.galvoPos in (gmin, gmax):
                first = i
            else:
                state = 2
        elif state == 2:
            if s.sensorData.galvoPos == otherEnd:
                last = i
                break
    if state != 2:
        print('sweep: failed to acquire sweep of scans')
        return None
    return scans[first:last + 1]


def plot_sweeps():
    global hsi

    paused = False
    def on_key(event):
        if event.key == ' ':
            nonlocal paused
            paused = not paused

    npixels = 196 # FIXME: until last 8 are no longer zeroes (FPGA update)
    xs = np.arange(npixels)

    s1, s2 = adjacent_scans(hsi)
    if s1 is None:
        return

    galvoP1 = s1.sensorData.galvoP1
    galvoP2 = s2.sensorData.galvoP2
    step = abs(s1.sensorData.galvoPos - s2.sensorData.galvoPos)
    print(f'plot_sweeps: from {galvoP1} to {galvoP2} step {step}')
    print('Use the <spacebar> to pause and unpause plot updates')

    fig = plt.figure()
    fig.canvas.mpl_connect('close_event', on_close)
    fig.canvas.mpl_connect('key_press_event', on_key)
    ax = fig.add_subplot(projection='3d')
    ylimits = None
    zlimits = None

    while hsi:
        if not paused:
            scans = sweep(hsi, galvoP1, galvoP2, step)
            if scans is None:
                break
            # Order highest galvoPos first for sensible 3D result
            # The data may display in reverse order with respect to actual
            if scans[0].sensorData.galvoPos < scans[-1].sensorData.galvoPos:
                scans = list(reversed(scans))
            ax.clear()

            # Allow Y limits to grow but never contract
            ydata = sorted([s.sensorData.galvoPos for s in scans])
            if ylimits is None:
                ylimits = [min(ydata), max(ydata)]
            else:
                tmp = [min(ydata) - 1, max(ydata) + 1]
                ylimits = [min(tmp[0], ylimits[0]), max(tmp[1], ylimits[1])]
            ax.set_ylim(ylimits)

            for i, scan in enumerate(scans):
                data = scan.sensorData.visData[:npixels] # FIXME
                ypos = scan.sensorData.galvoPos
                ax.plot(xs, data, zs=ypos, zdir='y', alpha=0.8)

                # Allow Z limits to grow but never contract
                if zlimits is None:
                    zlimits = [min(data), max(data)]
                else:
                    tmp = [min(data) - 1, max(data) + 1]
                    zlimits = [min(tmp[0], zlimits[0]), max(tmp[1], zlimits[1])]
                ax.set_zlim(zlimits)
            ax.set_xlabel('vis pixel band#')
            ax.set_ylabel('galvo pos')
            ax.set_zlabel('pixel band values')
            plt.show(block=False)
        plt.pause(0.1)


def plot_galvo(nscans=4000):
    global hsi

    plotStyle = '.'
    def on_key(event):
        if event.key == 'p':
            nonlocal plotStyle
            if plotStyle == '.':
                plotStyle = 'o'
            elif plotStyle == 'o':
                plotStyle = '-'
            else:
                plotStyle = '.'

    fig, ax = plt.subplots()
    fig.canvas.mpl_connect('close_event', on_close)
    fig.canvas.mpl_connect('key_press_event', on_key)
    while hsi:
        gpos = [s.sensorData.galvoPos
                for s in HSIo.scansFromBytes(hsi.getscans(nscans))]
        ax.clear()
        ax.plot(range(len(gpos)), gpos, plotStyle, color='gray')
        plt.show(block=False)
        plt.pause(0.1)


def verify_scans(hsi, quiet):
    def scan_generator():
        """ Convert binary scan data into Scans """
        for data in hsi.bindata('scans'):
            yield Scan(data)

    _verify_scans(scan_generator(), quiet)
    hsi.abort()

def verify_file(filename, quiet):
    _verify_scans(HSIo.scansFromFile(filename), quiet)

def _verify_scans(scans, quiet):
    """ Read scans continuously until stopped, reporting missed scans """
    def elapsed_time(millis):
        """ Return an elapsed millis in days/hours/minutes/seconds.millis """
        days = millis // 86400000
        millis -= days * 86400000
        hours = millis // 3600000
        millis -= hours * 3600000
        minutes = millis // 60000
        millis -= minutes * 60000
        seconds = millis / 1000
        return f'{days}d {hours:02d}:{minutes:02d}:{seconds:06.3f}'

    if quiet:
        print(':quiet mode; only errors will be shown')
    nscans = 0
    missed_scan = 0 # count of missing Scan.scanNum
    missed_seq = 0 # count of missing Scan.sensorData.seqNum

    try:
        # Read first Scan to set prevSeq
        scan = next(scans, b'')
        prevScan = scan.scanNum
        prevSeq = scan.sensorData.seqNum

        with open('errscans.smhs', 'wb') as errfile:
            # Subsequent scans should report the next increment higher mod 65536
            for scan in scans:
                nscans += 1
                scanNum = scan.scanNum
                seqNum = scan.sensorData.seqNum

                stats = f'{nscans} scanNum {scanNum} ' \
                        f'seqNum {seqNum:5d} ' \
                        f'timeStamp {scan.timeStamp} ' \
                        f'({elapsed_time(scan.timeStamp)}) ' \
                        f'(missed: scans:{missed_scan} seqs:{missed_seq})'

                error = False
                scanDiff = scanNum - prevScan
                seqDiff = (seqNum - prevSeq) & 0xffff
                if scanDiff != 1:
                    missed_scan += scanDiff
                    error = True
                if seqDiff != 1:
                    missed_seq += seqDiff
                    error = True

                if not quiet:
                    print(f'\r{stats}        ', end='')
                if error:
                    print('\nERROR '
                        f'scanNum:{prevScan}...{scanNum} ({scanDiff - 1}) '
                        f'seqNum:{prevSeq}...{seqNum} ({seqDiff - 1})')
                    errfile.write(scan.binary)
                else:
                    sys.stdout.flush()
                prevScan = scanNum
                prevSeq = seqNum
    except KeyboardInterrupt:
        print('\nKeyboard interrupt')


def deviceHeader(scan):
    """Create a JSON formatted header string containing device version info.

    Args:
        scan (Scan object): The Scan instance from which to retrieve metadata
    Returns:
        header string containing JSON metadata ending in a newline
    """
    metadata = {}

    metadata['utc'] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    metadata['device'] = f'{scan.deviceId.hex()}'
    metadata['verstr'] = scan.verstr
    sd = scan.sensorData
    metadata['fpgaver'] = \
            f'{sd.fpgaId:04x}.{sd.fpgaMajor:04x}.{sd.fpgaVersion:04x}'
    return json.dumps(metadata) + '\n'


def tocsv(hsi, binfile, csvfile):
    def csvHeader(scan, file):
        print(deviceHeader(scan), file=file)
        print('\n\n\n\n') # 5 extra lines
        print('scanNum,galvoPos', end='', file=file)
        for i in range(len(scan.sensorData.visData)):
            print(f',vis{i:03}', end='', file=file)
        for i in range(len(scan.sensorData.irData)):
            print(f',ir{i:02}', end='', file=file)
        print(file=file)

    if not os.access(binfile, os.R_OK):
        print(f'Cannot read file {binfile}')
        return
    if os.path.exists(csvfile):
        print(f'File {csvfile} already exists')
        return
    with open(csvfile, 'w') as csvf:
        header = 0
        for scan in HSIo.scansFromFile(binfile):
            if not header:
                csvHeader(scan, csvf)
                header = 1
            print(f'{scan.scanNum},{scan.sensorData.galvoPos}', end='',
                  file=csvf)
            for v in scan.sensorData.visData:
                print(f',{v}', end='', file=csvf)
            for v in scan.sensorData.irData:
                print(f',{v}', end='', file=csvf)
            print(file=csvf)


def command(hsi, cmd):
    def assertConnected(hsi):
        if hsi is None:
            usage("Not connected. Provide the 'ip' argument when using "
                    "networked commands")

    def assertCmdLen(cmd, minLen):
        if len(cmd) < minLen:
            usage("Not enough arguments")

    if isinstance(cmd, str):
        cmd = cmd.split(' ')

    if cmd[0] == 'shell':
        assertCmdLen(cmd, 2)
        os.system(' '.join(cmd[1:]))
    elif cmd[0] == 'scan':
        assertCmdLen(cmd, 2)
        assertConnected(hsi)
        scanToFile(hsi, cmd[1])
    elif cmd[0] == 'scans':
        if len(cmd) < 2 or len(cmd) > 4:
            usage("Incorrect arguments")
        folder = cmd[1]
        n = int(cmd[2]) if len(cmd) > 3 else None
        filename = cmd[3] if len(cmd) == 4 else ''
        assertConnected(hsi)
        filename, count, missed = scansToFile(hsi, folder, n, filename)
        print(f'{count} scans written to {filename} ({missed} missed scans)')
    elif cmd[0] == 'sweep':
        assertCmdLen(cmd, 2)
        print(hsi.sweep_pause(cmd[1]))
    elif cmd[0] == 'meta':
        assertCmdLen(cmd, 2)
        for scan in HSIo.scansFromFile(cmd[1]):
            print(scan.asStr())
    elif cmd[0] == 'livemeta':
        assertConnected(hsi)
        while True:
            print(hsi.getscan().asStr())
    elif cmd[0] == 'verify_scans':
        assertConnected(hsi)
        if len(cmd) > 1 and cmd[1] == '-q':
            verify_scans(hsi, True)
        else:
            verify_scans(hsi, False)
    elif cmd[0] == 'verify_file':
        assertCmdLen(cmd, 2)
        if cmd[1] == '-q':
            assertCmdLen(cmd, 3)
            verify_file(cmd[2], True)
        else:
            verify_file(cmd[1], False)
    elif cmd[0] == 'view':
        assertConnected(hsi)
        plot_both()
    elif cmd[0] == 'view_ir':
        assertConnected(hsi)
        plot(True)
    elif cmd[0] == 'view_vis':
        assertConnected(hsi)
        plot(False)
    elif cmd[0] == 'view_sweep':
        assertConnected(hsi)
        plot_sweeps()
    elif cmd[0] == 'view_galvo':
        assertConnected(hsi)
        if len(cmd) > 1:
            plot_galvo(int(cmd[1]))
        else:
            plot_galvo()
    elif cmd[0] == 'tocsv':
        assertCmdLen(cmd, 3)
        tocsv(hsi, cmd[1], cmd[2])
    else:
        usage(errorMessage="Command not recognized")


def main(argv):
    global hsi
    if len(argv) < 2:
        print('Error: not enough arguments')
        usage()

    ## Read optional arguments
    doFileMode = False
    offset = 1
    keepReading = True
    while keepReading and offset < len(argv):
        keepReading = False
        if argv[offset] == '-ip':
            if len(argv[offset:]) < 2:
                usage(errorMessage="Must provide IP address to '-ip' argument")
            ip = argv[offset + 1]
            if ip.find(':') > 0:
                ip, port = ip.split(':')[0:2]
                hsi = HSIo(ip, int(port))
            else:
                hsi = HSIo(ip)
            keepReading = True
            offset += 2
        elif argv[offset] == '-f':
            doFileMode = True
            keepReading = True
            offset += 1

    if doFileMode:
        if len(argv[offset:]) < 1:
            usage(errorMessage="Script name is required")
        with open(argv[offset], 'r') as script:
            for line in script:
                command(hsi, line.strip())
    else:
        if len(argv[offset:]) < 1:
            usage(errorMessage="Must provide a command to run")
        command(hsi, argv[offset:])


if __name__== '__main__':
    main(sys.argv)
