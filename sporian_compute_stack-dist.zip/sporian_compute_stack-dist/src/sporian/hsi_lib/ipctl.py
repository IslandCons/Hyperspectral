"""
Copyright (C) 2011-2017, Sporian Microsystems, Inc.
All Rights Reserved.

This document is the proprietary and confidential property of Sporian
Microsystems, Inc ("Sporian").  All use, distribution, reproduction or
re-distribution is disallowed without the prior written consent of Sporian
Microsystems, Inc.
"""

"""
Discover devices on local networks connected to this host.
Provide the additional capability to change device IP information.
"""

import sys
import errno
import time
import socket
import struct
import ipaddress

class Discover:
    """ The data from a device sent in response to a discover request """
    STRUCT_FMT = '!QIII'
    STRUCT_LEN = struct.calcsize(STRUCT_FMT)

    def __init__(self, address, binary):
        fmt = '!QIII'
        self.address = address
        self.guid, self.ipaddr, self.netmask, self.gateway = \
                struct.unpack(self.STRUCT_FMT, binary[:self.STRUCT_LEN])
        self.hostname = binary[self.STRUCT_LEN:].decode()
        self.ipaddr = ipaddress.ip_address(self.ipaddr)
        self.netmask = ipaddress.ip_address(self.netmask)
        self.interface = ipaddress.ip_interface(f'{self.ipaddr}/{self.netmask}')
        self.gateway = ipaddress.ip_address(self.gateway)

    def __repr__(self):
        return '{:x}: {} gw {} {}'.format(self.guid, self.interface,
                                          self.gateway, self.hostname)

ips = []
def hostips():
    global ips

    if len(ips) == 0:
        import psutil
        addrs = psutil.net_if_addrs()
        ips = []
        for k in addrs.keys():
            if k != 'lo':
                nicaddrs = addrs[k]
                for nicaddr in nicaddrs:
                    if nicaddr.family == socket.AF_INET:
                        if nicaddr.broadcast is not None:
                            ips.append(nicaddr.address)
    return ips


def listensock(port):
    """ Create the socket on which to listed for UDP broadcasts.
    Get this socket bound before sending any request broadcasts to avoid race
    conditions that could cause a reply to be missed.

    Args:
        port(int): The port to which to bind the socket.
    Returns:
        socket: The bound socket, set to non-blocking.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', port))
    sock.setblocking(0)
    return sock


def sendmsg(port, message):
    """ Broadcast via UDP a message on every network interface
    Args:
        port(int): The UDP port to which to send the message.
        message(bytes): The message send as payload in a UDP packet.
    """
    for ip in hostips():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((ip, 0))
        sock.sendto(message, ('255.255.255.255', port))
        sock.close()


def collect(devices, sock, waittime=0.1, output=False):
    """ Collect disocver reponses received as UDP broadcast messages.
    Args:
        devices(dict): Add new Discover responses to this dict, key is guid.
        sock(socket): The socket already bound and listening.
        timeout(float): Time in seconds to wait for UDP messages.
        output(bool): True if this function should print each received device
    Returns:
        dict(Discover): A dict of responses.  guid is the dict key.
    """
    # Send discovery packets a few times because UDP packets can be dropped.
    t0 = time.time()
    while time.time() - t0 < waittime:
        data = None
        address = None
        try:
            data, address = sock.recvfrom(1024)
        except socket.error as e:
            err = e.args[0]
            if err != errno.EAGAIN and err != errno.EWOULDBLOCK:
                print(':unexpected error')
                print(e)
        if data is not None:
            # sock will receive all broadcasts we sent ourselves, so ignore
            # short responses (the discover request) and responses that start
            # with b'S' (the ipset request).
            if data[0] != b'S'[0] and len(data) > Discover.STRUCT_LEN:
                device = Discover(address, data)
                if output and device.guid not in devices:
                    print(f'{device}')
                devices[device.guid] = device


def discover(port):
    """ Send discover packets and receive Discover replies.
    Returns:
        dict(Discover): A dict of responses, key is device guid.
    """
    recvsock = listensock(port)
    devices = {}
    for i in range(3):
        sendmsg(port, b'D')
        collect(devices, recvsock, output=True)
    print(f'{len(devices)} device(s) replied')
    return 0


def do_ipset(port, guid, ip, nm, gw):
    """ Send a set packet to the device with GUID guid.
    Args:
        port(int): The UDP port on which the set will be broadcasted, and the
            UDP port on which the device is expected to broadcast its reply.
        guid(int): The 64-bit GUID of the device that should respond to the
            set packet to be sent.
        ip(int): The 32-bit IP address already in network byte order.
        nm(int): The 32-bit subnet mask already in network byte order.
        gw(int): The 32-bit default gateway already in network byte order.
    """
    recvsock = listensock(port)
    message = b'S' + struct.pack('!QIII', guid, ip, nm, gw)
    devices = {}
    for i in range(3):
        sendmsg(port, message)
        collect(devices, recvsock)
    return devices


def usage():
    print('usage: %s [-p <port>] discover' % sys.argv[0])
    print('   or: %s [-p <port>] ipset <guid> <ip> <nm> <gw>' % sys.argv[0])
    print('The default port is 4001')
    sys.exit(1)


def ipset(port, args):
    """ Translate args into correct values for do_ipset() """
    if len(args) != 4:
        print('Invalid number of args')
        usage()
        return 1
    try:
        guid = int(args[0], 16)
        ip = int(ipaddress.ip_address(args[1]))
        nm = int(ipaddress.ip_address(args[2]))
        gw = int(ipaddress.ip_address(args[3]))
    except ValueError as e:
        print('One or more arguments are of the wrong type')
        print(e)
        usage()
        return 1
    devices = do_ipset(port, guid, ip, nm, gw)
    print(devices[guid])
    return 0


def main(argv):
    if len(argv) < 2:
        usage()

    port = 4001
    if argv[1] == '-p':
        port = int(argv[2])
        argv = argv[2:]
    command = argv[1]
    if command == 'discover':
        return discover(port)
    elif command == 'ipset':
        return ipset(port, argv[2:])
    else:
        return 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))

