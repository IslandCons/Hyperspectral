"""
Copyright (C) 2019-2022, Sporian Microsystems, Inc.
All Rights Reserved.

This document is the proprietary and confidential property of Sporian
Microsystems, Inc ("Sporian").  All use, distribution, reproduction or
re-distribution is disallowed without the prior written consent of Sporian
Microsystems, Inc.
"""

"""
This module that enables communication with a 2022 Hyperspectral Imager (HSI)
and the ability to work with HSI Scan objects.

HSI devices communicate Scans in a binary data format documented by the Scan
class and its subsidiary classes, below.  These classes are principally
provided to decode a binary scan into a Python Scan object.  However, these
classes also provide an encode() method and property setters to allow
code to create new Scans or modify existing ones.  Create and modify
capabilities are provided as a convenience for various testing purposes.

This code will not work with pre-2022 HSI devices as their data format differs.
See ssh://proj.sporian.com:29418/lpc/hyper.git:py/hsio.py for a version of this
code suitable for pre-2022 HSI devices.
"""

import io
import sys
import struct
import binascii
import socket
from threading import Lock
from . import tcpsio

class ScanConfig:
    """ Decoded scan configuration info, part of a Scan """
    STRUCT_FMT = '!ffffI'
    STRUCT_LEN = struct.calcsize(STRUCT_FMT)

    def __init__(self, packedData):
        self._irItime, self._uvItime, self._irGain, self._uvGain, \
                self._nAvg = struct.unpack(ScanConfig.STRUCT_FMT, packedData)

    def encode(self):
        """ Return the packed version of this object """
        return struct.pack(ScanConfig.STRUCT_FMT, self._irItime, self._uvItime,
                self._irGain, self._uvGain, self._nAvg)

    @property
    def irItime(self):
        return self._irItime

    @property
    def uvItime(self):
        return self._uvItime

    @property
    def irGain(self):
        return self._irGain

    @property
    def uvGain(self):
        return self._uvGain

    @property
    def nAvg(self):
        return self._nAvg

    def asDict(self):
        return {
            'irItime': self.irItime, 'uvItime': self.uvItime,
            'irGain': self.irGain, 'uvGain': self.uvGain, 'nAvg': self.nAvg
        }

    def asStr(self):
        retStr = 'irItime: {}\n'.format(self.irItime)
        retStr += 'uvItime: {}\n'.format(self.uvItime)
        retStr += 'irGain: {}\n'.format(self.irGain)
        retStr += 'uvGain: {}\n'.format(self.uvGain)
        retStr += 'nAvg: {}\n'.format(self.nAvg)
        return retStr

    @irItime.setter
    def irItime(self, val):
        self._irItime = val

    @uvItime.setter
    def uvItime(self, val):
        self._uvItime = val

    @irGain.setter
    def irGain(self, val):
        self._irGain = val

    @uvGain.setter
    def uvGain(self, val):
        self._uvGain = val

    @nAvg.setter
    def nAvg(self, val):
        if val < 0:
            raise ValueError('nAvg cannot be negative')
        self._nAvg = val


class ScanConditions:
    """ Decoded Condition information, part of a Scan """
    STRUCT_FMT = '!ffffHH'
    STRUCT_LEN = struct.calcsize(STRUCT_FMT)

    def __init__(self, packedData):
        self._irSaturation, self._uvSaturation, self._boardTemp, \
                self._sensorTemp, self._status, self._bitmark \
                = struct.unpack(ScanConditions.STRUCT_FMT, packedData)

    def encode(self):
        """ Return the packed version of this object """
        return struct.pack(ScanConditions.STRUCT_FMT,
                self._irSaturation, self._uvSaturation, self._boardTemp,
                self._sensorTemp, self._status, self._bitmark)

    @property
    def irSaturation(self):
        return self._irSaturation

    @property
    def uvSaturation(self):
        return self._uvSaturation

    @property
    def boardTemp(self):
        return self._boardTemp

    @property
    def sensorTemp(self):
        return self._sensorTemp

    @property
    def bitmark(self):
        return self._bitmark

    @property
    def status(self):
        return self._status

    def asDict(self):
        return {
            'irSaturation': self.irSaturation,
            'uvSaturation': self.uvSaturation, 'boardTemp': self.boardTemp,
            'sensorTemp': self.sensorTemp, 'bitmark': hex(self.bitmark),
            'status': hex(self.status)
        }

    def asStr(self):
        retStr = 'irSaturation: {}\n'.format(self.irSaturation)
        retStr += 'uvSaturation: {}\n'.format(self.uvSaturation)
        retStr += 'boardTemp: {}\n'.format(self.boardTemp)
        retStr += 'sensorTemp: {}\n'.format(self.sensorTemp)
        retStr += 'bitmark: {}\n'.format(hex(self.bitmark))
        retStr += 'status: {}\n'.format(hex(self.status))
        return retStr

    @irSaturation.setter
    def irSaturation(self, val):
        self._irSaturation = val

    @uvSaturation.setter
    def uvSaturation(self, val):
        self._uvSaturation = val

    @boardTemp.setter
    def boardTemp(self, val):
        self._boardTemp = val

    @sensorTemp.setter
    def sensorTemp(self, val):
        self._sensorTemp = val

    @bitmark.setter
    def bitmark(self, val):
        self._bitmark = val

    @status.setter
    def status(self, val):
        self._status = val

class SensorData:
    """ Decoded sensorData information, part of a Scan """

    STRUCT_FMT = '!256H'
    STRUCT_LEN = struct.calcsize(STRUCT_FMT) # 256 words == 512 bytes

    def __init__(self, packedData):
        words = struct.unpack(SensorData.STRUCT_FMT, packedData)

        self._fpgaId = words[0]
        self._fpgaMajor = words[1]
        self._fpgaVersion = words[2]
        self._seqNum = words[3]
        self._intTimeVis = words[4]
        self._galvoP1 = words[5]
        self._galvoPos = words[6]
        self._galvoP2 = words[7]
        self._visData = words[8:212]  # 204 pixels
        self._irData = words[212:228]  # 16 pixels
        self._zeroes = words[228:255]  # 27 zeroes
        self._checksum = words[255]
        self._ok = self._checksum == sum(words[:-1]) & 0xffff

    def encode(self):
        """ Return the packed version of this object """
        words = [self._fpgaId] + [self._fpgaMajor] + [self._fpgaVersion] + \
                [self._seqNum] + [self._intTimeVis] + [self._galvoP1] + \
                [self._galvoPos] + [self._galvoP2] + list(self._visData) + \
                list(self._irData) + list(self._zeroes) + [self._checksum]
        self._checksum = sum(words[:-1]) & 0xffff
        words[-1] = self._checksum
        binary = struct.pack(SensorData.STRUCT_FMT, *words)
        self._ok = len(binary) == SensorData.STRUCT_LEN
        return binary

    @property
    def ok(self):
        """ True if the contents pass certain checks like checksum """
        return self._ok

    @property
    def fpgaId(self):
        """ The fpgaId for 2022 HSI devices is 0x7012 """
        return self._fpgaId

    @property
    def fpgaMajor(self):
        return self._fpgaMajor

    @property
    def fpgaVersion(self):
        return self._fpgaVersion

    @property
    def seqNum(self):
        """ Incremented by one for each SensorData instance captured """
        return self._seqNum

    @property
    def intTimeVis(self):
        return self._intTimeVis

    @property
    def galvoP1(self):
        """ The left or lower edge of the galvo sweep range """
        return self._galvoP1

    @property
    def galvoPos(self):
        """ The right or upper edge of the galvo sweep range """
        return self._galvoPos

    @property
    def galvoP2(self):
        """ The galvo position at the time of SensorData capture """
        return self._galvoP2

    @property
    def visData(self):
        """ 204 'pixels' of data in the visible and lower UV bands """
        return self._visData

    @property
    def irData(self):
        """ 16 'pixels' of data in the upper IR bands """
        return self._irData

    @property
    def zeroes(self):
        """ Reserved for future use """
        return self._zeroes

    @property
    def checksum(self):
        """ The lower 16 bits of the sum of all other words in a SensorData
        instance.
        """
        return self._checksum

    def asDict(self):
        """ Return the contents of the instance as a dictionary """
        return {
            'fpgaId': hex(self.fpgaId),
            'fpgaMajor': hex(self.fpgaMajor),
            'fpgaVersion': hex(self.fpgaVersion),
            'seqNum': self.seqNum,
            'intTimeVis': self.intTimeVis,
            'galvoP1': self.galvoP1,
            'galvoPos': self.galvoPos,
            'galvoP2': self.galvoP2,
            'visData': self.visData,
            'irData': self.irData,
            'zeroes': self.zeroes,
            'checksum': '{} {}'.format(self.checksum,
                                       'ok' if self.ok else 'BAD')
        }
        return retStr

    def asStr(self):
        """ Return the contents of the instance as a string """
        def listAsStr(name, l, n=10):
            return '{}: ({} of {}) {} ...\n'.format(name, n, len(l), l[:n])

        retStr = 'fpgaId: {}\n'.format(hex(self.fpgaId))
        retStr += 'fpgaMajor: {}\n'.format(hex(self.fpgaMajor))
        retStr += 'fpgaVersion: {}\n'.format(hex(self.fpgaVersion))
        retStr += 'seqNum: {}\n'.format(self.seqNum)
        retStr += 'intTimeVis: {}\n'.format(self.intTimeVis)
        retStr += 'galvoP1: {}\n'.format(self.galvoP1)
        retStr += 'galvoPos: {}\n'.format(self.galvoPos)
        retStr += 'galvoP2: {}\n'.format(self.galvoP2)
        retStr += listAsStr('visData', self.visData)
        retStr += listAsStr('irData', self.irData)
        retStr += listAsStr('zeroes', self.zeroes)
        retStr += 'checksum: {} {}\n'.format(self.checksum,
                'ok' if self.ok else 'BAD')
        return retStr

    @fpgaId.setter
    def fpgaId(self, val):
        self._fpgaId = val

    @fpgaMajor.setter
    def fpgaMajor(self, val):
        self._fpgaMajor = val

    @fpgaVersion.setter
    def fpgaVersion(self, val):
        self._fpgaVersion = val

    @seqNum.setter
    def seqNum(self, val):
        self._seqNum = val

    @intTimeVis.setter
    def intTimeVis(self, val):
        self._intTimeVis = val

    @galvoP1.setter
    def galvoP1(self, val):
        self._galvoP1 = val

    @galvoPos.setter
    def galvoPos(self, val):
        self._galvoPos = val

    @galvoP2.setter
    def galvoP2(self, val):
        self._galvoP2 = val

    @visData.setter
    def visData(self, val):
        self._visData = val

    @irData.setter
    def irData(self, val):
        self._irData = val

    @zeroes.setter
    def zeroes(self, val):
        self._zeroes = val

    @checksum.setter
    def checksum(self, val):
        self._checksum = val

class Scan:
    """ A decoded Scan """
    STRUCT_LEN_FMT = '!H'
    STRUCT_LEN_LEN = struct.calcsize(STRUCT_LEN_FMT)
    STRUCT_FMT = STRUCT_LEN_FMT + 'H6sHII64s'
    STRUCT_LEN = struct.calcsize(STRUCT_FMT)

    """ Bit definitions for the flags field """
    SCAN_F_RTC = 1 << 0

    # FIXME: fromStream() is broken: read() may return less than requested
    def fromStream(stream):
        """ Read a Scan from Stream `stream`.
        Args:
            stream(Stream): A Stream from which binary scan data can be read.
        Returns:
            bytes: One binary scan, or
            None: If a Scan is not available on `stream`
        """
        binary = stream.read(Scan.STRUCT_LEN_LEN)
        if len(binary) != Scan.STRUCT_LEN_LEN: #eof
            return None
        scanLen = struct.unpack(Scan.STRUCT_LEN_FMT, binary)[0]
        binary += stream.read(scanLen - Scan.STRUCT_LEN_LEN)
        if len(binary) != scanLen: #eof
            return None
        return Scan(binary)

    def __init__(self, scan=None):
        """
        Initialize a Scan instance with binary scan data, for example data
        returned from HSIo.getscan() or HSIo.bindata().
        """
        if scan is not None:
            self._binary = scan
        else:
            # Create an empty Scan object whose only valid field is '_len'.
            self._binary = struct.pack(Scan.STRUCT_LEN_FMT, Scan.STRUCT_LEN);
            self._binary += b'\0' * (Scan.STRUCT_LEN - len(self._binary))

        i = 0
        self._len, self._version, self._deviceId, self._flags, \
                self._timeStamp, self._scanNum, self._verstr, = \
                struct.unpack(Scan.STRUCT_FMT, scan[i:i + Scan.STRUCT_LEN])
        i += Scan.STRUCT_LEN

        # Remove NUL byte padding from verstr (when shorter than 64 chars)
        self._verstr = self._verstr.decode().rstrip('\0')

        self._config = ScanConfig(scan[i: i + ScanConfig.STRUCT_LEN])
        i += ScanConfig.STRUCT_LEN

        self._conditions = ScanConditions(scan[i: i + ScanConditions.STRUCT_LEN])
        i += ScanConditions.STRUCT_LEN

        self._sensorData = SensorData(scan[i:i + SensorData.STRUCT_LEN])
        i += SensorData.STRUCT_LEN

        self._crc = struct.unpack('!H', scan[-2:])[0]
        self._crcCalculated = binascii.crc_hqx(self.binary[:-2], 0)
        self._ok = i + 2 == len(scan)

    def encode(self):
        """ Update the binary scan data with the current contents of the class.
        """
        verstr = self._verstr.encode('utf-8')
        verstr = verstr + b'\0' * (64 - len(verstr)) # NUL pad verstr

        i = 0
        self.binary = struct.pack(Scan.STRUCT_FMT,
                self._len, self._version, self._deviceId, self._flags,
                self._timeStamp, self._scanNum, verstr)

        self.binary += self._config.encode()
        self.binary += self._conditions.encode()
        self.binary += self._sensorData.encode()
        self._crcCalculated = binascii.crc_hqx(self.binary, 0)
        self.binary += struct.pack('!H', self._crcCalculated)
        self._crc = self._crcCalculated
        self._ok = len(self.binary) == Scan.STRUCT_LEN
        return self.binary

    @property
    def len(self):
        """ The length of the Scan including the bytes defining its length """
        return self._len

    @property
    def version(self):
        """ The version of the Scan.  2022 HSI devices are version TBD. """
        return self._version

    @property
    def deviceId(self):
        """ The unique ID of the HSI device which captured this Scan.
        2022 HSI devices use their Ethernet MAC address as their device ID.
        """
        return self._deviceId

    @property
    def flags(self):
        """ Scan flags: SCAN_F_RTC """
        return self._flags

    @property
    def timeStamp(self):
        """ Time at the moment of Scan acquisition.

        - If Scan.flags & SCAN_F_RTC, this field contains the on-board RTC
          value in seconds at the time of Scan acquisition.  Unless the HSI
          device has an on-board RTC battery, the RTC value is reset to 0 on
          each power up.  Nominally one expects the RTC value to be the POSIX
          Epoch time, which is the number of seconds since midnight the morning
          of Jan 1, 1970 UTC.

        - If !(Scan.flags & SCAN_F_RTC), the timeStamp field contains the
          number of milliseconds since the start of the most recent scan
          command at the time of Scan acquisition.
        """
        return self._timeStamp

    @property
    def scanNum(self):
        """ Scan number.
        Scan numbers are monotonic and guaranteed to never be reused until the
        scan number value rolls over from 2**32 - 1 to 0.  The combination of
        deviceId and scanNum combine to create a universally unique scan
        identifier.
        """
        return self._scanNum

    @property
    def verstr(self):
        """ Firwmare version.
        The firmware version string is padded with NUL bytes if it contains less
        than 64 characters.  If the string is 64 characters in length, the string
        does not contain a trailing NUL byte.
        """
        return self._verstr

    @property
    def config(self):
        return self._config

    @property
    def conditions(self):
        return self._conditions

    @property
    def sensorData(self):
        return self._sensorData

    @property
    def crc(self):
        """ An ITU-T CRC-16 computed over all data fields in the scan """
        return self._crc

    @property
    def crcCalculated(self):
        """ The CRC-16 as calculated upon instantiation of this Scan object.
        This value should be the same as self.crc if the Scan has not been
        corrupted.
        """
        return self._crcCalculated

    @property
    def binary(self):
        """ The binary "on the wire" version of this Scan """
        return self._binary

    @property
    def ok(self):
        """ True if the Scan binary data appears correct """
        return self._ok

    def asDict(self):
        """ Return the contents of this Scan as a dictionary """
        d = {
            'len': self.len,
            'version': self.version,
            'deviceId': self.deviceId.hex(),
            'flags': f'{self.flags:02x}',
            'timeStamp': self.timeStamp,
            'scanNum': self.scanNum,
            'verstr': self.verstr,
            'crc': hex(self.crc),
            'crcCalculated': '{} ({})'.format(hex(self.crcCalculated),
                'ok' if self.crc == self.crcCalculated else 'BAD')
        }
        d.update(self.config.asDict())
        d.update(self.conditions.asDict())
        d.update(self.sensorData.asDict())
        return d

    def asStr(self):
        """ Return the stringified version of all the scan data """
        retStr = 'len: {} bytes\n'.format(self.len)
        retStr += 'version: {}\n'.format(self.version)
        retStr += 'deviceId: {}\n'.format(self.deviceId.hex())
        retStr += 'flags: {:02x}\n'.format(self.flags)
        retStr += 'timeStamp: {}\n'.format(self.timeStamp)
        retStr += 'scanNum: {}\n'.format(self.scanNum)
        retStr += 'verstr: {}\n'.format(self.verstr)
        retStr += self.config.asStr()
        retStr += self.conditions.asStr()
        retStr += self.sensorData.asStr()
        retStr += 'crc: {}\n'.format(hex(self.crc))
        retStr += 'crcCalculated: {} ({})\n'.format(hex(self.crcCalculated),
                'ok' if self.crc == self.crcCalculated else 'BAD')
        return retStr

    @len.setter
    def len(self, val):
        self._len = val

    @version.setter
    def version(self, val):
        self._version = val

    @deviceId.setter
    def deviceId(self, val):
        self._deviceId = val

    @flags.setter
    def flags(self, val):
        self._flags = val

    @timeStamp.setter
    def timeStamp(self, val):
        self._timeStamp = val

    @scanNum.setter
    def scanNum(self, val):
        self._scanNum = val

    @verstr.setter
    def verstr(self, val):
        self._verstr = val

    @config.setter
    def config(self, val):
        self._config = val

    @conditions.setter
    def conditions(self, val):
        self._conditions = val

    @sensorData.setter
    def sensorData(self, val):
        self._sensorData = val

    @crc.setter
    def crc(self, val):
        self._crc = val

    @crcCalculated.setter
    def crcCalculated(self, val):
        self._crcCalculated = val

    @binary.setter
    def binary(self, val):
        self._binary = val

    @ok.setter
    def ok(self, val):
        self._ok = val

class HSIo:
    """ Interact with an HSI device """
    def __init__(self, ip, port=tcpsio.DEFAULT_PORT, debug = False):
        self.tcpsio = tcpsio.tcpsio(ip=ip, port=port)

    def abort(self):
        """ See tcpsio for details """
        self.tcpsio.abort()

    def cmd(self, command, binaryArg=None):
        """ See tcpsio for details """
        return self.tcpsio.cmd(command, binaryArg)

    def bindata(self, command):
        """ See tcpsio for details """
        return self.tcpsio.bindata(command, '!H')

    def cmdlns(self, command):
        """ See tcpsio for details """
        return self.tcpsio.cmdlns(command)

    def fpgacmd(self, cmd):
        """ Send an FPGA command to the HSI device, returning the response.
        """
        try:
            return self.cmdlns('fpga ' + cmd)[0]
        except tcpsio.TcpsioError as msg:
            print(msg, file=sys.stderr)
            return

    def sweep_pause(self, cmd):
        """ Pause sweep w/pause == True, then resume w/pause == False.
        Returns the first line of output from the HSI device, or None on
        failure to communicate.  The first line's first character will be '1'
        if sweeping has been paused, '0' if sweeping has resumed, or another
        character on usage error.
        """
        try:
            return self.cmdlns('sweep ' + cmd)[0]
        except tcpsio.TcpsioError as msg:
            print(msg, file=sys.stderr)
            return

    def getscan(self):
        """ Request a single Scan from the HSI device.  Use getscans() or
        bindata('scans') to stream scans from the HSI device at full speed.

        Returns:
            Scan: The received scan data, or
            None: on error
        """
        try:
            return Scan(self.cmd('scan'))
        except tcpsio.TcpsioError as msg:
            print(msg, file=sys.stderr)
            return

    def getscans(self, count):
        """ Request `count` scans from the HSI device.
        Args:
            count(int): The number of scans to request.  A minimum of 1 is
                enforced.
        Returns:
            bytes: The raw scan data for all scans, or
            None: on error
        """
        data = bytearray(b'')
        try:
            if count <= 0:
                count = 1
            for binblock in self.bindata(f'scan {count}'):
                data.extend(binblock) # FIXME: we could be smarter
        except tcpsio.TcpsioError as msg:
            print(msg, file=sys.stderr)
            return
        return bytes(data)

    def scans(self):
        """ Return a generator that can read scan data from the HSI device at
        full speed.  Scans are terminated on network error or by calling
        abort().

        Yields:
            bytes: binary data for one scan.
        """
        return board.bindata('scans', '!H')

    def scansFromFile(filename):
        """ Generator that reads Scans from a file.
        Args:
            filename(str): The filename containing the scans.
        Yields
            scan (Scan): Scans converted from binary data read from the file
        """
        with open(filename, 'rb') as file:
            while True:
                scan = Scan.fromStream(file)
                if scan is None:
                    break
                yield scan

    def scansFromBytes(data):
        """ Generator that reads Scans from a bytes value.
        Args:
            data(bytes): The data containing one or more scans.
        Yields
            scan (Scan): Scans converted from binary data read from the file
        """
        with io.BytesIO(data) as file:
            while True:
                scan = Scan.fromStream(file)
                if scan is None:
                    break
                yield scan
