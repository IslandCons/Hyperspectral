"""
Copyright (C) 2019-2022, Sporian Microsystems, Inc.
All Rights Reserved.

This document is the proprietary and confidential property of Sporian
Microsystems, Inc ("Sporian").  All use, distribution, reproduction or
re-distribution is disallowed without the prior written consent of Sporian
Microsystems, Inc.
"""

"""
hsisim.py

This code simulates a Sporian hyperspectral imager (HSI).  The simulator allows
the "playback" of HSI scans stored in disk file(s), previously captured from an
HSI device.  Run this program on a PC and then connect to it's IP address on
port 4000 using code (derived) from hsio.py to retrieve scans.

This simulator simulates the 2022 Hyperspectral Imager (HSI).  Pre-2022 HSI
devices use a different Scan data format.
"""

import sys
import os
import socket
import errno
import time
from hsio import Scan

def usage(msg):
    if msg:
        print(f'*** {msg} ***')
    print("""
usage: python3 [-p <port>] [-r] hsisim.py [files...]
    Simulate a 2022+ Sporian Hyperspectral Imager (HSI) device.
    Provide one or more files on the command line containing HSI binary scan
    data.  The simulator will deliver all scans from each file in the order
    listed.
Options:
    -p <port>: Port to which to bind.  The default is 4000, the same as used on
        HSI devices.

Supported commands:
    The HSI device provides a command line facility on its port.  Only a subset
    of the HSI device commands are supported by the simulator:

    info: Report information about the HSI device.  This command isn't
        generally necessary to use as each delivered scan includes the most
        important information presented in the info command.

    scan [n]: Deliver n scans to the connected host.  If n is not provided,
        deliver a single scan.

    scans: Deliver scans continuously to the connected host.  The host can
        terminate delivery by sending any byte to the HSI device.  The scan
        being delivered at time of byte send will be delivered in its entirety
        before delivery stops.
""")
    sys.exit(1)


class ScanSource:
    def __init__(self, rate=2300):
        self.period = 1.0 / rate
        self.nextTime = time.time() + self.period
        self.files = []
        self.reset()

    def reset(self):
        self.findex = -1
        self.file = None
        self.scan = None

    def setFiles(self, strOrList):
        if isinstance(strOrList, str):
            self.files = strOrList.split()
        else:
            self.files = strOrList
        if len(self.files) == 0:
            usage('No files provided; need at least one')
        for f in self.files:
            if not os.path.isfile(f):
                usage(f'No file {f}')
            else:
                with open(f, 'rb') as file:
                    scan = Scan.fromStream(file)
                    if scan is None:
                        usage(f'File {f} has no scans')

    def current(self):
        """ Return the current scan.  None is no current scan. """
        return self.scan

    def delay(self):
        """ Do not deliver scans faster than once every self.period seconds """
        while time.time() < self.nextTime:
            pass
        self.nextTime += self.period
        tmp = time.time()
        while self.nextTime < tmp:
            self.nextTime += self.period

    def next(self):
        """ Return the next scan """
        if self.file:
            self.scan = Scan.fromStream(self.file)
            if self.scan is not None:
                self.delay()
                return self.scan
        # End of current file, open new file
        self.findex += 1
        if self.findex >= len(self.files):
            self.findex = 0
        self.file = open(self.files[self.findex], 'rb')
        self.scan = Scan.fromStream(self.file)

        # Because files were checked in setFiles() for at least 1 scan ea,
        # self.scan should not be None unless files altered after prog start.
        self.delay()
        return self.scan

# Global instance initially has no files
scanSource = ScanSource()


def readline(sock):
    """ Read a CR and/or LF terminated string, returning the string stripped.
    """
    command = b''
    while len(command) == 0 or command[-1] not in [10, 13]: # CR or LF
        tmp = sock.recv(1024)
        if len(tmp) == 0:
            break;
        command += tmp
    return command.decode().strip()


def readcommand(sock):
    """ Read a CR and/or LF terminated string, returning a list of space
    separated tokens within the string.  An empty list is possible.
    """
    tokens = readline(sock).split()
    if len(tokens) == 0:
        return '', []
    elif len(tokens) == 1:
        return tokens[0], []
    else:
        return tokens[0], tokens[1:]


def sendstr(sock, string, end='\r\n'):
    string += end
    sock.send(string.encode('utf-8'))


def sendscan(sock, scan):
    nsent = 0
    while nsent < len(scan):
        tmp = sock.send(scan)
        if tmp == 0:
            print(':scan write error (client probably disappeared)')
            break
        nsent += tmp
        scan = scan[tmp:]


def cmd_info(sock, args):
    tag = 'unknown'
    verstr = 'unknown'
    id = '010203040506'
    sendstr(sock, f'Name       hsi_simulator')
    sendstr(sock, f'Platform   PC')
    sendstr(sock, f'Tag        {tag}')
    sendstr(sock, f'Verstr     {verstr}')
    sendstr(sock, f'Device id  {id}')


def cmd_reset(sock, args):
    """ The HSI device resets.  The simulator resets the scanSource. """
    global scanSource
    scanSource.reset()


def cmd_scan(sock, args):
    global scanSource
    count = 1 if len(args) == 0 else int(args[0])
    for i in range(count):
        sendscan(sock, scanSource.next().binary)


def cmd_scans(sock, args):
    def sockdata():
        """ Return true if data on socket or socket has closed """
        hasData = True
        sock.setblocking(0)
        try:
            data = sock.recv(1)
        except socket.error as e:
            err = e.args[0]
            if err == errno.EAGAIN or err == errno.EWOULDBLOCK:
                hasData = False;
            else:
                print(':unexpected error')
                print(e)
        sock.setblocking(1)
        return hasData;

    global scanSource
    while not sockdata():
        sendscan(sock, scanSource.next().binary)


def main(argv):
    prompt = b'hsi> '
    port = 4000

    args = argv[1:]
    while len(args) > 1 and args[0][0] == '-':
        if args[0] == '-p':
            try:
                port = int(args[1])
            except (ValueError, IndexError) as e:
                usage('Error decoding port # after -p argument')
            args = args[2:]

    global scanSource
    scanSource.setFiles(args)
    print(f':{len(scanSource.files)} files ready')

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    #server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    addr = ('localhost', port)
    server.bind(addr)
    server.listen(1)

    while True:
        try:
            print(':wait for connection')
            conn, client = server.accept()
            while True:
                command, args = readcommand(conn)
                if command:
                    print(f':command {command}')
                    if command == 'info':
                        cmd_info(conn, args)
                    elif command == 'reset':
                        cmd_reset(conn, args)
                    elif command == 'scan':
                        cmd_scan(conn, args)
                    elif command == 'scans':
                        cmd_scans(conn, args)
                    else:
                        sendstr(conn,
                                f"No such command '{command}'.  Try 'help'")
                conn.send(prompt)
        except (ConnectionResetError, BrokenPipeError) as e:
            #print(e)
            print(':client has disconnected')


if __name__== '__main__':
    main(sys.argv)
