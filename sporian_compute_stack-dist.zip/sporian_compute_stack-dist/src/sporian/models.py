import logging
from django.db import models
from sporian.hsi_lib.hsio import Scan as HsiScan
import plotly.graph_objects as go
from plotly.io import to_html
import numpy as np
import struct

logger = logging.getLogger(f"compute_node.{__name__}")


class Scan(models.Model):
    mission = models.ForeignKey('drone.Mission', on_delete=models.CASCADE)

    relative_time = models.IntegerField()
    scanNum = models.BigIntegerField(unique=True)
    
    len = models.CharField(max_length=20)
    version = models.CharField(max_length=20)
    deviceId = models.CharField(max_length=20)
    flags = models.CharField(max_length=20)
    timeStamp = models.IntegerField()
    verstr = models.CharField(max_length=20)
    verstr = models.CharField(max_length=40)
    crc = models.CharField(max_length=20)

    irItime = models.FloatField()
    uvItime = models.FloatField()
    irGain = models.FloatField()
    uvGain = models.FloatField()
    nAvg = models.FloatField()

    irSaturation = models.FloatField()
    uvSaturation = models.FloatField()
    boardTemp = models.FloatField()
    sensorTemp = models.FloatField() 
    bitmark = models.CharField(max_length=8)
    status = models.CharField(max_length=8)

    fpgaId = models.CharField(max_length=8)
    fpgaMajor = models.CharField(max_length=8)
    fpgaVersion = models.CharField(max_length=8)
    seqNum = models.IntegerField()
    intTimeVis = models.IntegerField()
    galvoP1 = models.IntegerField()
    galvoPos = models.IntegerField()
    galvoP2 = models.IntegerField()

    visData = models.BinaryField()
    irData = models.BinaryField()

    def __str__(self):
        return f"Scan: {self.scanNum}"

    class Meta:
        ordering = ['mission', '-timeStamp']
        indexes = [
            models.Index(fields=["timeStamp", "scanNum"]),
            models.Index(fields=["scanNum"], name="scanNum_idx"),
        ]
    
    @classmethod
    def from_binary(cls, scan, mission, relative_time):
        scan_data = HsiScan(scan).asDict()
        for bin_field in ['visData', 'irData']:
            data = scan_data[bin_field]
            scan_data[bin_field] = struct.pack(
                '!{}i'.format(len(data)), *data
            )
        bad_keys = ['crcCalculated', 'checksum', 'zeroes']
        for bk in bad_keys:
            del scan_data[bk]
        return cls(
            mission=mission,
            relative_time=relative_time,
            **scan_data)

    @staticmethod
    def _unpack_struct_data(binary_data):
        integer_array = struct.unpack('!{}i'.format(len(binary_data) // 4), binary_data)
        return list(integer_array)
    
    @property
    def vis_data(self):
        return self._unpack_struct_data(self.visData)
        
    @property
    def ir_data(self):
        return self._unpack_struct_data(self.irData)
    
    def create_vis_fig(self):
        y_values = self.vis_data
        fig = self._create_fig(y_values)
        vis_plot = to_html(fig, full_html=False, include_plotlyjs=False)
        return vis_plot

    def create_ir_fig(self):
        y_values = self.ir_data
        fig = self._create_fig(y_values)
        ir_plot = to_html(fig, full_html=False, include_plotlyjs=False)
        return ir_plot

    def _create_fig(self, data):
        x_values = np.arange(len(data))
        fig = go.Figure(data=go.Scatter(x=x_values, y=data, mode='markers'))
        return fig
