import os
import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from hsi_lib.normalize import *
from lib import ScanSource

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
PROBA_DF = None
REF_SIGS = None

##############################
# Base functions
##############################

def normalize_vis(sarr):
    sarr = sarr.astype('float32') - sarr.mean(axis=1)[:,np.newaxis]
    sarr /= sarr.std(axis=1)[:,np.newaxis]
    return sarr


def render_scan_figures(fname, scan_ids):
    with open(fname, 'rb') as f:
        scans_by_id = ScanSource(f).fetch_scan_ids(scan_ids)
    fig = go.Figure()
    fig_norm = go.Figure()
    for sid, scan in scans_by_id.items():
        scan_row = PROBA_DF.loc[PROBA_DF['scan_id'] == sid]
        scan_label = scan_row.material.values[0]
        vis_data = scan.sensorData.visData
        fig.add_trace(
            go.Scatter(
                x=np.arange(len(vis_data)), y=vis_data,
                mode='lines+markers',
                name=f'{sid} (C: {scan_label})'
            )
        )
        fig_norm.add_trace(
            go.Scatter(
                x=np.arange(len(vis_data)),
                y=normalize_vis(np.array([vis_data]))[0],
                mode='lines+markers',
                name=f'{sid} (C: {scan_label})'
            )
        )
        for sig_label, sig_data in REF_SIGS.items():
            fig.add_trace(
                go.Scatter(
                    x=np.arange(len(vis_data)),
                    y=sig_data['raw'],
                    mode='lines',
                    name=f'Ref: {sig_label}'
                )
            )
            fig_norm.add_trace(
                go.Scatter(
                    x=np.arange(len(vis_data)),
                    y=sig_data['norm'],
                    mode='lines',
                    name=f'Ref: {sig_label}'
                )
            )
    for f in [fig, fig_norm]:
        f.update_layout(legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        ))
    return fig, fig_norm


##############################
# Callbacks
##############################

@app.callback(
    Output('scatter-plot', 'figure'),
    Input('result-input', 'value')
)
def load_scatter(result_path):
    if not os.path.exists(result_path):
        raise IOError(f"File: {result_path} does not exist")

    app.logger.info(f"Loading result scatter: {result_path}")
    global PROBA_DF
    PROBA_DF = pd.read_csv(result_path)
    # PROBA_DF['size_mat'] = 1
    # PROBA_DF['size_imp'] = 1

    hover_data = PROBA_DF.columns
    # ["scan_id", "ctype", "total_diff", "class_2", "class_3"]
    
    fig = px.scatter(
        PROBA_DF,
        x="galvo_pos", y="timestamp",
        color='material', hover_data=hover_data,
        # symbol_sequence=['bowtie'],
        height=1000,
        # size='size_mat',
        title=f"Results: {os.path.basename(result_path)}"
    )
    # fig.add_traces(
    #     list(
    #         px.scatter(
    #             PROBA_DF,
    #             x="galvo_pos", y="timestamp",
    #             symbol_sequence=['hourglass'],
    #             size='size_imp',
    #             color='impurity', hover_data=['impurity'],
    #         ).select_traces()
    #     )
    # )
    fig.update_layout(
        xaxis = dict(autorange="reversed"),
        yaxis = dict(autorange="reversed"),
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01
        ),
    )
    fig.update_traces(marker_line_width=0)
    return fig


@app.callback(
    Output('hidden-div', 'children'),
    Input('reference-input', 'value')
)
def load_references(ref_data_path):
    if not os.path.exists(ref_data_path):
        raise IOError(f"File: {ref_data_path} does not exist")

    def load_references(dframe):
        refs = {}
        for label, ldf in dframe.groupby('label'):
            label_samples = ldf.sample(n=50)
            vis_samples = np.array(label_samples.vis_data.to_list())
            refs[label] = {
                "raw": np.median(vis_samples, axis=0),
                "norm": np.median(normalize_vis(vis_samples), axis=0)
            }
        return refs

    global REF_SIGS
    app.logger.info(f"Loading references from: {ref_data_path}")
    tdf = pd.read_pickle(ref_data_path)
    REF_SIGS = load_references(tdf)
    app.logger.info(f"References loaded: {REF_SIGS.keys()}")
    return None


@app.callback(
    [
        Output('sensor-plot-1', 'figure'), 
        Output('sensor-plot-2', 'figure'), 
    ],
    Input('scatter-plot', 'clickData'),
    State('scanpath-input', 'value')
)
def load_scan_graphs(clickData, scanpath):
    if clickData is None:
        return go.Figure(), go.Figure()
    app.logger.info(clickData)
    scan_id = clickData['points'][0]['customdata'][0]
    app.logger.info(scan_id)
    if not (scanpath and os.path.exists(scanpath)):
        raise IOError(f"Scanpath: {scanpath} not found")
    fig, fig_norm = render_scan_figures(scanpath, [scan_id])
    return fig, fig_norm


##############################
# Create layout
##############################

app.layout = html.Div(
    id="app-container",
    className="row",
    children=[
        dcc.Interval(
            id="load_interval", 
            n_intervals=0, 
            max_intervals=0, #<-- only run once
            interval=1
        ),
        # Left column
        html.Div(
            className="col-4 col-lg-2 col-xxl-2 pomat_panel",
            children=[
                html.Div(id='hidden-div', style={'display':'none'}),
                html.Div(
                    id="control-card",
                    children=[
                        html.P("Result File Path"),
                        dcc.Input(
                            className="w-100",
                            id="result-input", type="text",
                            value="/opt/spectrabotics/sporian/sporian_notebooks/Ndim_Cosine/test_cossine_result.csv",
                            debounce=True
                        ),
                        html.Hr(),
                        html.P("Scan File Path"),
                        dcc.Input(
                            className="w-100",
                            id="scanpath-input", type="text", 
                            value="/opt/spectrabotics/sporian/local_data/20230808/raw_data/20230807_1237L_gravel_bg_cap_red_blue_panels.smhs",
                            debounce=True
                        ),
                        html.Hr(),
                        html.P("Reference Scan Path"),
                        dcc.Input(
                            className="w-100",
                            id="reference-input", type="text", 
                            value="../local_data/all_references.pkl",
                            debounce=True
                        ),
                    ],
                )
            ]
        ),
        # Right column
        html.Div(
            className="col-8 col-lg-10 col-xxl-10",
            children=[
                html.Div(
                    className="row",
                    children=[
                        html.Div(
                            className="col-6",
                            children=[
                                html.H4('Result scatter plot'),
                                dcc.Graph(id="scatter-plot"),
                            ]
                        ),
                        html.Div(
                            className="col-6",
                            children=[
                                html.H4('Sensor Scans'),
                                dcc.Loading(
                                    id="scans-loading",
                                    children=[
                                        html.H5('Original Scans'),
                                        dcc.Graph(id="sensor-plot-1"),
                                        html.H5('Normalized Scans'),
                                        dcc.Graph(id="sensor-plot-2"),
                                    ],
                                    type="circle",
                                ),
                            ]
                        )
                    ]
                )
            ]
        )
    ]
)


##############################
# Start Server
##############################

if __name__ == '__main__':
    app.run_server(debug=True, port=8060)
