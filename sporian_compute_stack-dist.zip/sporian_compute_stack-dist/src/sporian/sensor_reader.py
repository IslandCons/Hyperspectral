import os
import time
import logging
import redis
from django.core.cache import cache
from .hsi_lib.hsio import Scan, HSIo

logger = logging.getLogger(f"compute_node.{__name__}")


# Classes for thread workers
class HsioMemoryBuffer():
    """A class to read scans endlessly into alternating RAM stores"""
    
    hsi = None
    # Store data in alternating blocks so IO time doesn't lose scans
    data_pages = {
        0: [],
        1: []
    }
    page_index = 0
    init_scan = None
    # Scan starting number
    init_scan_num = 0
    redis_client = None

    def __init__(self, sensor_address, **kwargs):
        self.log = logging.getLogger(self.__class__.__name__)
        # Initialize the thread super
        ip, port = sensor_address.split(":")
        # Now create hsi instance
        attempts = 0
        while self.hsi == None:
            try:
                attempts += 1
                self.log.info(f"Attempting to connect to ({ip}:{int(port)})")
                self.hsi = HSIo(ip, int(port))
            except:
                if attempts > 10:
                    raise
                self.log.exception("Exception connecting to sensor. Waiting")
                time.sleep(1)
        self._init_redis_conn()
        self.scans = self.hsi.bindata('scans')
        self.init_scan_num = self._wait_for_scans()

    def _init_redis_conn(self):
        self.redis_client = redis.StrictRedis(
            host=os.environ["REDIS_HOST"],
            port=os.environ["REDIS_PORT"], db=3
        )
    
    def _wait_for_scans(self):
        scandata = b''
        while scandata == b'':
            scandata = next(self.scans, b'')
            self.log.info("Waiting for scan received")
            time.sleep(0.1)
        scan = Scan(scandata)
        self.init_scan = scan
        self.sync_data = {
            "system_time": time.time(),
            "scan_time": scan.timeStamp,
            "scan_num": scan.scanNum,
        }
        return scan.scanNum
    
    def run_loop(self, lock_id):
        self.log.info("Starting scan loop")
        scan_id = 0
        
        def yield_scans(size=100, max_id=5000):
            nonlocal scan_id
            scan_dict = {}
            for scandata in self.scans:
                scan_dict[f"scan.{scan_id}"] = bytes(scandata)
                scan_id = (scan_id + 1) % max_id
                if scan_id % size == 0:
                    yield scan_id, scan_dict

        check_counter = 0
        while True:
            # Check if we need to break while loop
            check_counter += 1
            if check_counter > 10:
                check_counter = 0
                if not cache.get(lock_id):
                    raise ConnectionAbortedError("Exiting collection")
            try:
                for latest_scan_id, scan_dict in yield_scans():
                    self.redis_client.mset(scan_dict)
                    self.redis_client.set(
                        "latest_scan", latest_scan_id, ex=10
                    )
                    logger.info(f"Cached scans up to: {latest_scan_id}")
            except:
                self.log.exception("Unexpected exception reading scans")
                time.sleep(0.1)
