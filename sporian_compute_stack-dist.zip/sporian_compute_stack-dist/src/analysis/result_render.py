import os
import logging
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from analysis.models import Classifier

logger = logging.getLogger(f"compute_node.{__name__}")



##############################
# Base functions
##############################
def normalize_vis(sarr):
    sarr = sarr.astype('float32') - sarr.mean(axis=1)[:,np.newaxis]
    sarr /= sarr.std(axis=1)[:,np.newaxis]
    return sarr


def convert_galvo_ang(galvo):
    return (2.9043E-04 * galvo) - 11.36628


def render_scan_figures(scan):
    logger.info("Loading scan figures")

    fig = go.Figure()
    fig_norm = go.Figure()

    sid = scan.scanNum
    # scan_row = PROBA_DF.loc[PROBA_DF['scan_id'] == sid]
    # scan_label = scan_row.material.values[0]
    vis_data = scan.vis_data
    fig.add_trace(
        go.Scatter(
            x=np.arange(len(vis_data)), y=vis_data,
            mode='lines+markers',
            name=f'{sid}'
        )
    )
    fig_norm.add_trace(
        go.Scatter(
            x=np.arange(len(vis_data)),
            y=normalize_vis(np.array([vis_data]))[0],
            mode='lines+markers',
            name=f'{sid}'
        )
    )
    for f in [fig, fig_norm]:
        f.update_layout(
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            autosize=True,
            height=600,
        )
    return fig, fig_norm


def render_scan_figures_refs(clf, scan, material_name=None):
    from analysis.util import normalize
    logger.info("Loading scan figures")
    
    fig, fig_norm = render_scan_figures(scan)
    
    for idx, material in enumerate(clf.materials.all()):
        scan_sample = material.scans.order_by("?")[:100]
        opacity = 0.3
        if material_name and material.material_id in material_name:
            opacity = 1
        
        vis_data = [
            scan.vis_data
            for scan in scan_sample
        ]
        fig.add_trace(
            go.Scatter(
                x=np.arange(len(vis_data[0])),
                y=np.median(vis_data, axis=0),
                mode='lines', opacity=opacity,
                name=f'{material}'
            )
        )
        fig_norm.add_trace(
            go.Scatter(
                x=np.arange(len(vis_data[0])),
                y=np.median(normalize(vis_data), axis=0),
                mode='lines', opacity=opacity,
                name=f'{material}'
            )
        )
    return fig, fig_norm


def load_scatter(mission_choice, classifier_choice):
    logger.info("Loading scatter")
    if not (mission_choice and classifier_choice):
        return
    classifier = Classifier.objects.get(pk=classifier_choice)
    result_path = classifier.result_path(mission_choice)

    if not os.path.exists(result_path):
        raise IOError(f"File: {result_path} does not exist")

    logger.info(f"Loading result scatter: {result_path}")
    global PROBA_DF
    PROBA_DF = pd.read_csv(result_path).sample(n=int(1E5))
    
    # Easy way to threshold confidence
    # PROBA_DF = PROBA_DF[PROBA_DF['static_confidence'] > 0.95]

    hover_data = PROBA_DF.columns
    PROBA_DF['material_name'] = PROBA_DF['material'].str.split('_').str[1]
    PROBA_DF['galvo_pos'] = convert_galvo_ang(PROBA_DF['galvo_pos'])
    # ["scan_id", "ctype", "total_diff", "class_2", "class_3"]
    
    fig = px.scatter(
        PROBA_DF,
        x="galvo_pos", y="timestamp",
        color='material_name', hover_data=hover_data,
        # symbol_sequence=['bowtie'],
        height=1000,
        # size='size_mat',
        title=f"Results: {os.path.basename(result_path)}"
    )

    fig.update_layout(
        yaxis = dict(autorange="reversed"),
        xaxis = dict(range=[-10, 10]),
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01
        ),
    )
    fig.update_traces(marker_line_width=0)
    return fig
