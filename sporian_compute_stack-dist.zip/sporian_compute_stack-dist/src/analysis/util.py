import numpy as np


def normalize(arr, reflectance=None):
    """Normalize an array by mean/stdev"""
    arr = np.array(arr).astype('float32')
    if reflectance is not None:
        arr /= reflectance
    arr = arr - arr.mean(axis=1)[:,np.newaxis]
    arr /= arr.std(axis=1)[:,np.newaxis]
#     arr = savgol_filter(arr, 11, polyorder=2, deriv=2)
    return arr


def norm_single_scan(sarr):
    sarr = sarr.astype('float32') - sarr.mean()
    sarr /= sarr.std()
    return sarr
