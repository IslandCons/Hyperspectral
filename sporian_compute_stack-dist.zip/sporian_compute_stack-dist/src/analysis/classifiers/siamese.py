import time
import logging
import pandas as pd
import numpy as np
import tensorflow as tf
import tensorflow.keras.backend as K
tf.config.experimental_run_functions_eagerly(True)
from analysis.util import normalize

logger = logging.getLogger(f"compute_node.{__name__}")


class SiameseClassifier():
    
    scan_meta = None
    ident_df = None
    
    def __init__(self, clf_model, ref_df):
        self.ref_df = ref_df
        self.clf_instance = clf_model
        self.dynamic_scale = clf_model.dynamic_scale
        self.ref_signals = np.array(ref_df.signal.to_list())
        self.model = self._load_model(clf_model.model_path)

    def _load_model(self, model_path):
        def contrast_loss(y, preds, margin=1):
            y = tf.cast(y, preds.dtype)
            squaredPreds = K.square(preds)
            squaredMargin = K.square(K.maximum(margin - preds, 0))
            loss = (y * squaredPreds + (1 - y) * squaredMargin)
            return loss

        sporian_model = tf.keras.models.load_model(
            model_path, 
            custom_objects={"contrast_loss": contrast_loss},
        )
        return sporian_model

    def classify_scans(self, scan_df):
        pred_df = scan_df[['scanNum', 'timeStamp', 'galvoPos']].copy()
        # Change the column names
        pred_df.rename(columns={
            'scanNum': 'scan_id',
            'timeStamp': 'timestamp',
            'galvoPos': 'galvo_pos',
        }, inplace=True)

        spectra_input = np.array(scan_df.vis_data.tolist())
        
        if self.dynamic_scale:
            calibrate_sig = self.clf_instance.get_reflectance(
                pred_df['scan_id'].iloc[0]
            )
            spectra_input = normalize(
                spectra_input, reflectance=calibrate_sig)
        else:
            spectra_input = normalize(
                spectra_input)
        ref_signals = self.ref_signals

        # Prepare the data for classification
        logger.info(
            f"Classifying scans, shape={spectra_input.shape}")
        
        tiles = spectra_input.shape[0]
        spectra_stack = np.repeat(
            spectra_input, self.ref_df.shape[0], axis=0)
        # Repeat the reference signal sufficiently
        reference_stack = np.repeat(ref_signals, tiles, axis=0)

        scan_pred = self.model.predict([
            reference_stack, spectra_stack
        ])
        # Now reshape back to original shape
        scan_pred = scan_pred.reshape(-1, self.ref_df.shape[0])
        scan_pred = (scan_pred * -1) + 1 # Convert from difference into similarity
        
        # Now put that altogether in dataframe
        df = pd.DataFrame(
            scan_pred,
            columns=[f"similarity.{l}" for l in self.ref_df.label]
        )
        df['similarity.background'] = 0.5
        most_similar = df.idxmax(axis="columns") # Like argmax for numpy
        df['material'] = most_similar.str.split('.').str[1]
        pdf = pd.concat([pred_df, df], axis=1)
        return pdf
    
    def create_result_df(self, pred_df, fpath):
        pred_df.set_index('scan_id').to_csv(fpath)
        logger.info(f"Saved result to: {fpath}")


class SiameseClassifierONNX():
    
    scan_meta = None
    ident_df = None
    
    def __init__(self, clf_model, ref_df):
        self.ref_df = ref_df
        self.ref_signals = np.array(ref_df.signal.to_list()).astype(np.float32)
        self.dynamic_scale = clf_model.dynamic_scale

        # self.model = self._load_model(model_path)
        sess, output_name = self._get_onnx_runtime(clf_model.model_path_onnx)
        
        self.onnx_session = sess
        self.model_output_name = output_name

    def _get_onnx_runtime(self, model_path):
        import onnxruntime as ort
        logger.info(f"Creating ONNX runtime - model: {model_path}")
        sess = ort.InferenceSession(
            model_path, providers=[
                'CUDAExecutionProvider',
                'CPUExecutionProvider'
            ])
        output_name = sess.get_outputs()[0].name
        # output_name = sess.get_outputs()[0].name
        input_names = [i.name for i in sess.get_inputs()]
        assert input_names == ['input_1', 'input_2'], \
            "Input_names do not match expectation!"
        logger.info(
            f"Loaded {model_path} - " 
            f"Output={output_name} Inputs={input_names}")
        return sess, output_name

    def classify_scans(self, scan_df):
        tstart = time.time()
        pred_df = scan_df[['scanNum', 'timeStamp', 'galvoPos']].copy()
        # Change the column names
        pred_df.rename(columns={
            'scanNum': 'scan_id',
            'timeStamp': 'timestamp',
            'galvoPos': 'galvo_pos',
        }, inplace=True)

        spectra_input = np.array(scan_df.vis_data.tolist()).astype(np.float32)

        if self.dynamic_scale:
            calibrate_sig = self.clf_instance.get_reflectance(
                pred_df['scan_id'].iloc[0]
            )
            spectra_input = normalize(
                spectra_input, reflectance=calibrate_sig)
        else:
            spectra_input = normalize(
                spectra_input)

        # Prepare the data for classification
        logger.info(
            f"Classifying scans, shape={spectra_input.shape}")
        
        tiles = spectra_input.shape[0]
        spectra_stack = np.repeat(
            spectra_input, self.ref_df.shape[0], axis=0)
        # Repeat the reference signal sufficiently
        reference_stack = np.repeat(self.ref_signals, tiles, axis=0)

        # Classify it all
        logger.info(
            f"Comparing scans against all materials ({spectra_stack.shape})")
        outputs = self.onnx_session.run(
            [self.model_output_name], {
                "input_1": reference_stack,
                "input_2": spectra_stack
            }
        )[0]
        tclf = time.time()
        logger.info(f"Classified {spectra_input.shape} in {tclf-tstart}s: {outputs.shape}")
        # logger.info(f"Outputs preview: {outputs[:50]}")
        split_arrays = np.squeeze(np.array(
            np.split(outputs, self.ref_df.shape[0], axis=0)
        ), axis=-1).T
        # logger.info(f"Split shape {split_arrays.shape}")
        # Stack the smaller arrays horizontally
        # reshaped_array = np.hstack(split_arrays)
        df = pd.DataFrame(
            1 + (split_arrays * -1),
            columns=[f"similarity.{l}" for l in self.ref_df.label]
        )
        df['similarity.background'] = 0.5
        most_similar = df.idxmax(axis="columns") # Like argmax for numpy
        df['material'] = most_similar.str.split('.').str[1]
        # logger.info(f"Pred DF head:\n {df.head()}")
        pdf = pd.concat([pred_df, df], axis=1)
        logger.info(f"Concat DF head:\n {pdf.head()}")
        return pdf
    
    def create_result_df(self, pred_df, fpath):
        pred_df.set_index('scan_id').to_csv(fpath)
        logger.info(f"Saved result to: {fpath}")
