import logging
from django.contrib import admin
from .models import Classification, Material, Classifier, RESDAN, Siamese, NClass
from .tasks import classify_mission as clf_task
from django.http import HttpResponseRedirect
from django.shortcuts import render


logger = logging.getLogger(f"compute_node.{__name__}")



def classify_mission(self, request, queryset):
    if "apply" in request.POST:
        mission = int(request.POST["mission"])
        for clf in queryset:
            logger.info(f"Going to classify {mission}")
            clf_task.delay(clf.id, mission)
        return HttpResponseRedirect(request.get_full_path())

    return render(
        request,
        "admin/clf_mission.html",
        context={"classifiers": queryset},
    )


def classify_all_missions(self, request, queryset):
    from drone.models import Mission
    for clf in queryset:
        for mission in Mission.objects.all():
            logger.info(f"Going to classify {mission}")
            clf_task.delay(clf.id, mission.id)
    return HttpResponseRedirect(request.get_full_path())


@admin.register(Classification)
class ClassificationAdmin(admin.ModelAdmin):
    list_display = ("material_predicted", "scanNum")


@admin.register(RESDAN)
class ResdanAdmin(admin.ModelAdmin):
    list_display = ("name", "static_threshold", "n_components")
    actions = [classify_mission, classify_all_missions]


@admin.register(Siamese)
class SiameseAdmin(admin.ModelAdmin):
    list_display = ("name",)
    actions = [classify_mission,]


@admin.register(NClass)
class NClassAdmin(admin.ModelAdmin):
    list_display = ("name",)
    actions = [classify_mission,]


@admin.register(Material)
class MaterialAdmin(admin.ModelAdmin):
    list_display = ("material_id", "scanNum_start", "scanNum_end", "galvo_start", "galvo_end")