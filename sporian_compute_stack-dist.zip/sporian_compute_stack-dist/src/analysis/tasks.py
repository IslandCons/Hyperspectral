from celery.utils.log import get_task_logger
from compute_node.celery import app
from sporian.models import Scan
from analysis.models import Classifier

logger = get_task_logger(f"compute_node.{__name__}")


@app.task(bind=True, soft_timeout=60)
def classify_range(self, start_scan=None, end_scan=None):
    scans = Scan.objects.filter(scanNum__lt=end_scan, scanNum__gt=start_scan)
    logger.info(f"Fetched scans for analysis: {scans}")


@app.task(bind=True, soft_timeout=60)
def classify_selected(self, start_scan=None, end_scan=None):
    scans = Scan.objects.filter(scanNum__lt=end_scan, scanNum__gt=start_scan)
    logger.info(f"Fetched scans for analysis: {scans}")


@app.task(bind=True, soft_timeout=3*60*60)
def classify_mission(self, clf_id, mission_id):
    clf = Classifier.objects.get(id=clf_id)
    result = clf.classify_mission(mission_id)
    logger.info(f"Classification result: {result}")
