import os
import time
import pickle
import logging
from django.db import models
from polymorphic.models import PolymorphicModel
from sporian.models import Scan
from sporian.models import HsiScan
from drone.models import Mission
from plotly.io import to_html
import plotly.graph_objects as go
from django.conf import settings
import numpy as np
import pandas as pd
import tensorflow as tf
from django.utils import timezone
from multiprocessing.pool import ThreadPool
from multiprocessing import Pool

# tf.config.experimental_run_functions_eagerly(True)


logger = logging.getLogger(f"compute_node.{__name__}")


# Material instances associate a material ID with an array of scans
class Material(models.Model):
    material_id = models.CharField(max_length=128)
    galvo_start = models.BigIntegerField()
    galvo_end = models.BigIntegerField()
    scanNum_start = models.BigIntegerField()
    scanNum_end = models.BigIntegerField()

    def __str__(self):
        return f"{self.material_id} [{self.scanNum_start} - {self.scanNum_end}]"
    
    @property
    def scans(self):
        return Scan.objects.filter(
            scanNum__lt=self.scanNum_end,
            scanNum__gt=self.scanNum_start,
            galvoPos__lt=self.galvo_end,
            galvoPos__gt=self.galvo_start,
        )

    @property
    def scan_count(self):
        return len(self.scanNums)

    def build_plot(self, sample_count=None, sample_perc=None):
        scans = self.scans
        if sample_perc:
            sample_count = int(scans.count() / 100 * sample_perc)
        elif not sample_count:
            raise
        scan_sample = self.scans.order_by("?")[:sample_count]
        scan_med = []
        traces = []
        for scan in scan_sample:
            scan_med.append(scan.vis_data)
            traces.append(
                go.Scatter(
                    x=np.arange(len(scan.vis_data)), y=scan.vis_data,
                    mode='lines', name=f'Scan {scan.scanNum}',
                    line=dict(color='rgba(255, 0, 0, 0.1)')
                )
            )
        scan_med = np.median(scan_med, axis=0)
        traces.append(go.Scatter(
            x=np.arange(len(scan_med)), y=scan_med,
            mode='lines', name=f'Scan {scan.scanNum}',
            line=dict(color='rgba(0, 0, 255, 0.8)')
        ))
        layout = go.Layout(title='Material Samples',
                           xaxis=dict(title='Wavelength'),
                           yaxis=dict(title='Intensity'))
        # Create the figure with traces and layout
        fig = go.Figure(data=traces, layout=layout)
        ir_plot = to_html(fig, full_html=False, include_plotlyjs=False)
        return ir_plot

    def _create_fig(self, data):
        x_values = np.arange(len(data))
        fig = go.Figure(data=go.Scatter(x=x_values, y=data, mode='markers'))
        return fig


# ------------------------
# ----- CLASSIFIERS ------
# ------------------------
class Classifier(PolymorphicModel):
    name = models.CharField(max_length=30, unique=True)

    def classify_mission(self, mission_id):
        raise NotImplementedError("Not Implemented")

    def classify_mission_realtime(self, mission_id):
        raise NotImplementedError("Not Implemented")

    @staticmethod
    def build_df(scans):
        scan_df = pd.DataFrame(scans)
        scan_df.sort_values(by='scanNum', inplace=True)
        logger.info(f"Built ScanDF ({scan_df.shape}):\n{scan_df.head()}")
        return scan_df

    @staticmethod
    def process_file(fpath):
        scan_data = []
        with open(fpath, "rb") as f:
            data = pickle.load(f)
            scans = [
                HsiScan(l)
                for l in data
            ]
        scan_data = [{
            "scanNum": scan.scanNum,
            "galvoPos": scan.sensorData.galvoPos,
            "timeStamp": scan.timeStamp,
            "vis_data": scan.sensorData.visData,
            "ir_data": scan.sensorData.irData,
        } for scan in scans]
        return scan_data
    
    def load_scans_from_files(self, scan_file_paths, num_processes=4, threaded=True):
        # Create a pool of processes
        if threaded:
            with ThreadPool(num_processes) as pool:
                results = pool.map(self.process_file, scan_file_paths)
        else:
            with Pool(num_processes) as pool:
                results = pool.map(self.process_file, scan_file_paths)
        # Flatten the list of lists
        scans = [item for sublist in results for item in sublist]
        return scans

    def yield_scan_dataframe(self, mission_id, chunk_size=5E5, full_scans=True):
        chunk_size = int(chunk_size)
        # Retrieve all scan archive files
        logger.info("Retrieving Scans from Disk")
        
        # If retrieving full scans, reduce chunk_size
        # we will read more from disk
        if full_scans:
            chunk_size = int(chunk_size / settings.SCAN_PARSE_INTERVAL)

        scansQS = Scan.objects.filter(
            mission_id=mission_id
        ).order_by('scanNum')
        earliest_scannum = scansQS.earliest('scanNum').scanNum
        latest_scannum = scansQS.latest('scanNum').scanNum

        if not full_scans:
            for i in range(0, scansQS.count() - chunk_size, chunk_size):
                scans = [{
                        "scanNum": s.scanNum,
                        "galvoPos": s.galvoPos,
                        "timeStamp": s.timeStamp,
                        "vis_data": s.vis_data,
                        "ir_data": s.ir_data,
                    }
                    for s in scansQS[i:i+chunk_size]
                ]
                yield self.build_df(scans)
        else:
            scan_archives = {}
            for root, _, files in os.walk(settings.SCAN_STORE_DIR):
                for f in files:
                    if not f.endswith(".pkl"):
                        continue
                    scannum = f.split(".")[1]
                    scan_archives[scannum] = os.path.join(root, f)
            scan_keys = sorted(scan_archives.keys())

            scans = []
            for skey in scan_keys:
                if int(skey) < earliest_scannum or int(skey) > latest_scannum:
                    continue
                with open(scan_archives[skey], "rb") as f:
                    data = pickle.load(f)
                    for l in data:
                        s = HsiScan(l)
                        scans.append({
                            "scanNum": s.scanNum,
                            "galvoPos": s.sensorData.galvoPos,
                            "timeStamp": s.timeStamp,
                            "vis_data": s.sensorData.visData,
                            "ir_data": s.sensorData.irData,
                        })
                if len(scans) > chunk_size:
                    yield self.build_df(scans)
                    scans = []
            yield self.build_df(scans)


class RESDAN(Classifier):

    static_threshold = models.FloatField(
        default=0.1, help_text="Threshold for static spectra detection")
    materials = models.ManyToManyField(Material)
    n_components = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"Resdan ST({self.static_threshold}) N({self.n_components})"

    def result_path(self, mission_id, part=""):
        return os.path.join(
            "/data", f"analysis_RESDAN_{self.pk}_Mission_{mission_id}{part}.csv")

    def classify_mission(self, mission_id):
        raise NotImplementedError("RESDAN classifier not included")
        # from analysis.classifiers.resdan import CosineClassifier
        # logger.info("Building Spectral Signatures")
        # sig_df = self._build_signatures()

        # df_file_paths = []
        # for idx, scan_df in enumerate(self.yield_scan_dataframe(mission_id)):
        #     logger.info("Initializing Classifier")
        #     cclf = CosineClassifier(
        #         self.static_threshold,
        #         scan_df, sig_df,
        #         n_comp=self.n_components)
        #     logger.info("Building spectral separations")
        #     cclf.spectral_classify()
        #     logger.info("Generating spectral DF")
        #     cclf.generate_spectral_df()
        #     logger.info("Iterating solver")
        #     cclf.iter_solve_mat()
        #     file_part_path = self.result_path(mission_id, part=f"-{idx}")
        #     cclf.create_result_df(file_part_path)
        #     df_file_paths.append(file_part_path)
        # result_df = pd.concat((
        #     pd.read_csv(f) for f in df_file_paths), ignore_index=True)
        # result_df.to_csv(self.result_path(mission_id))


    def _build_signatures(self):
        from analysis.util import normalize

        df = []
        for material in self.materials.all():
            scan_samples = material.scans.order_by("scanNum")
            # for batch in yield_batch(scan_samples):
            vis_data = normalize([
                scan.vis_data
                for scan in scan_samples
            ])
            vis_data = np.median(vis_data, axis=0)
            df.append({
                "label": f"{material.pk}_{material.material_id}",
                "signal": vis_data
            })
        df = pd.DataFrame(df)
        logger.info(f"Spectral Signatures:\n{df.head()}")
        return df


class Siamese(Classifier):
    materials = models.ManyToManyField(Material)
    dynamic_scale = models.BooleanField(default=False)

    def __str__(self):
        return f"Siamese"

    def result_path(self, mission_id, part=""):
        return os.path.join(
            "/data", f"analysis_Siamese_{self.pk}_Mission_{mission_id}{part}.csv")

    @property
    def model_path(self):
        return os.path.join(
            "/data", f"model_Siamese_{self.pk}")

    @property
    def model_path_onnx(self):
        return os.path.join(
            "/data", f"model_Siamese_onnx_{self.pk}")

    @staticmethod
    def get_reflectance(scanNum):
        scan_set = Scan.objects.filter(
            scanNum__lt=scanNum
        ).order_by('-scanNum')[:1000]
        return np.max(
            np.array([
                scan.vis_data
                for scan in scan_set
            ]), axis=0
        )

    def create_onnx_model(self):
        import subprocess
        logger.info("Converting model for Onnx runtime")
        command = [
            "python3", "-m", "tf2onnx.convert",
            "--saved-model", self.model_path,
            "--output", self.model_path_onnx
        ]
        logger.info(f"Running: {' '.join(command)}")
        subprocess.run(command, check=True)

    def classify_mission(self, mission_id):
        from analysis.classifiers.siamese import SiameseClassifier
        logger.info("Loading Reference Spectra")
        ref_df = self._get_reference_spectra()

        logger.info("Starting Siamese classification")
        df_file_paths = []
        cclf = SiameseClassifier(
            self, ref_df)
        for idx, scan_df in enumerate(
                self.yield_scan_dataframe(
                    mission_id, full_scans=False, chunk_size=1E4
                )
            ):
            pred_df = cclf.classify_scans(scan_df)
            file_part_path = self.result_path(mission_id, part=f"-{idx}")
            cclf.create_result_df(pred_df, file_part_path)
            df_file_paths.append(file_part_path)
        result_df = pd.concat((
            pd.read_csv(f) for f in df_file_paths), ignore_index=True)
        result_df.to_csv(self.result_path(mission_id))
    
    def _get_reference_spectra(self):
        from analysis.util import normalize

        df = []
        for material in self.materials.all():
            scan_samples = material.scans.order_by("scanNum")
            logger.info(
                f"Loading samples for material ({material.material_id})"
                )
            if len(scan_samples) == 0:
                logger.warning(
                    f"No samples found - discarding"
                )
                continue

            if self.dynamic_scale:
                reflectance = self.get_reflectance(scan_samples[0].scanNum)
                vis_data = normalize([
                    scan.vis_data
                    for scan in scan_samples
                ], reflectance=reflectance)
            else:
                vis_data = normalize([
                    scan.vis_data
                    for scan in scan_samples
                ])

            vis_data = np.median(vis_data, axis=0)
            df.append({
                "label": f"{material.pk}_{material.material_id}",
                "signal": vis_data
            })
        df = pd.DataFrame(df)
        logger.info(f"Spectral Signatures:\n{df.head()}")
        return df


class NClass(Classifier):
    materials = models.ManyToManyField(Material)

    def __str__(self):
        return f"NClass"

    def result_path(self, mission_id, part=""):
        return os.path.join(
            "/data", f"analysis_NClass_{self.pk}_Mission_{mission_id}{part}.csv")

    @property
    def model_path(self):
        return os.path.join(
            "/data", f"model_NClass_{self.pk}")

    def classify_mission(self, mission_id):
        import joblib
        from analysis.util import normalize

        logger.info("Starting NClass classification")
        df_file_paths = []
        for idx, scan_df in enumerate(
                self.yield_scan_dataframe(mission_id, chunk_size=1E4)
            ):
            loaded_model = joblib.load(self.model_path)
            result_df = pd.DataFrame({
                "scan_id": scan_df['scanNum'],
                "timestamp": scan_df['timestamp'],
                "galvo_pos": scan_df['galvoPos']
            })
            norm_vis_data = normalize(scan_df['vis_data'])
            logger.info("Initializing Classifier")
            material = loaded_model.predict(norm_vis_data)
            result_df['material'] = material
            file_part_path = self.result_path(mission_id, part=f"-{idx}")
            df_file_paths.append(file_part_path)
        result_df = pd.concat((
            pd.read_csv(f) for f in df_file_paths), ignore_index=True)
        result_df.to_csv(self.result_path(mission_id))


# ------------------------
# ---- CLASSIFICATION ----
# ------------------------
# Classification objects capture a single classification of a single scan
class Classification(models.Model):
    material_predicted = models.ForeignKey(Material, on_delete=models.CASCADE)
    classifier = models.ForeignKey(Classifier, on_delete=models.CASCADE)

    scanNum = models.BigIntegerField()
    confidence = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)
