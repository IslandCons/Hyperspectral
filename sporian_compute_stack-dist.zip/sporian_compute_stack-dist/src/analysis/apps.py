import logging

from django.apps import AppConfig

logger = logging.getLogger("compute_node.%s" % __name__)


class AnalysisConfig(AppConfig):
    name = "analysis"

    def ready(self):
        pass
