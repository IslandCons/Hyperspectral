#!/bin/python3
"""
Sporian compute processor
Threaded application running partly on GPU
Reads data from Sporian Sensor or Simulator
Classifies data using ML, writes raw data and results to disk
"""

import os
import sys
import time
import click
import django
import logging
import pandas as pd
from django.core.cache import cache
from multiprocessing import Process
import itertools
# import Jetson.GPIO as GPIO

PROJECTPATH = '/opt/compute_node/'
sys.path.insert(0, PROJECTPATH)
os.environ.setdefault("REDIS_HOST", "redis_int")
os.environ.setdefault("REDIS_PORT", "6379")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "compute_node.settings")
os.environ["DJANGO_ALLOW_ASYNC_UNSAFE"] = "true"  # https://docs.djangoproject.com/en/4.1/topics/async/#async-safety
os.chdir(PROJECTPATH)
django.setup()

from analysis.models import Siamese
from drone.models import Mission
from sporian.models import Scan
from django.utils import timezone
from django.conf import settings

# Setup Logger
logger = logging.getLogger()
sh = logging.StreamHandler()
sh.setFormatter(
    logging.Formatter(
        "%(asctime)s [%(levelname)s] - %(name)s - %(message)s"
    )
)
logger.setLevel(logging.INFO)
# logger.addHandler(sh)

PAGE_SIZE = 3

class ScanDataPrep(Process):
    """A class to read pages of scans and store/process them.
    Processed data stored in alternating pages."""
    
    # Store data in alternating blocks so IO time doesn't lose scans
    page_index = 0
    max_spectra_in_page = int(os.environ.get("MAX_SCANS_CLF_BATCH", 1000))

    def __init__(self, classifier, mission, chunk_size=1E3, **kwargs):
        super().__init__(**kwargs)
        self.classifier = classifier
        self.mission = mission
        self.chunk_size = chunk_size

        self.log = logging.getLogger(self.__class__.__name__)
        
        self.scan_set = Scan.objects.filter(
            mission=self.mission
        )
        if not self.scan_set.exists():
            raise Exception(f"No scans for mission: {self.mission}")
        self.search_scan_files()

    def search_scan_files(self):
        scan_archives = []
        self.log.info(
            f"Retrieving all full-scan files [{settings.SCAN_STORE_DIR}]")
        for root, _, files in os.walk(settings.SCAN_STORE_DIR):
            for f in sorted(files):
                if not f.endswith(".pkl"):
                    continue
                try:
                    scannum = int(f.split(".")[1])
                except:
                    continue
                scan_archives.append({
                    "scanNum": scannum, "file": os.path.join(root, f)
                })
        self.scan_file_df = pd.DataFrame(scan_archives)

    def run(self, idle_timeout=15):
        self.log.info("Starting feed loop")
        tstart = time.time()

        last_scanNum = 0
        last_scan_batch_time = timezone.now()
        while True:
            self.log.info("Preparing next batch of scans")
            scansQS = self.scan_set.filter(
                scanNum__gt=last_scanNum
            ).order_by('scanNum')[:self.chunk_size]

            self.log.info(f"Retrieved {scansQS.count()} scans in batch")
            if scansQS.count() > 0:
                last_scan_batch_time = timezone.now()
            else: 
                seconds_since = (
                    timezone.now() - last_scan_batch_time
                ).total_seconds()
                if seconds_since > idle_timeout:
                    raise TimeoutError(f"No scans received in {idle_timeout}s")
                time.sleep(0.1)
                continue
            
            scansQS = list(scansQS)
            earliest_scannum = scansQS[0].scanNum
            latest_scannum = scansQS[-1].scanNum
            last_scanNum = latest_scannum

            self.log.info(
                f"Retrieving full-scans {earliest_scannum} to {latest_scannum}")
            # if scannum > earliest_scannum and scannum < latest_scannum:
                #     scan_archives[scannum] = 
            scan_files = self.scan_file_df[
                (self.scan_file_df['scanNum'] >= earliest_scannum) &
                (self.scan_file_df['scanNum'] <= latest_scannum)
            ]['file'].tolist()

            self.log.info(f"Processing files {len(scan_files)}")
            scans = self.classifier.load_scans_from_files(
                scan_files, threaded=False) # 500ms for ~30 files
            
            if len(scans) == 0:
                self.log.info(f"No scans found")
                continue

            self.log.info(f"Saving to data page: {len(scans)} scans")
            
            cache.set(
                f'datapage_{self.page_index}',
                self.classifier.build_df(scans)
            )
            cache.set(f'datapage_ready_{self.page_index}', True)
            self.log.info("Data Page ready")
            
            cache.set("rt_dataprep_time", time.time() - tstart)
            cache.set("rt_dataprep_size", len(scans))

            self.page_index = (self.page_index + 1) % PAGE_SIZE

            self.log.info("Waiting for page consumption")
            while cache.get(f'datapage_ready_{self.page_index}'):
                time.sleep(0.05)
            tstart = time.time()


@click.command()
@click.argument('classifier_id', type=int)
@click.argument('mission_id', type=int)
def main(classifier_id, mission_id):
    """Script to run with two integer arguments: classifier_id and mission_id."""
    try:
        clf = Siamese.objects.get(pk=classifier_id)
    except:
        raise Exception("Classifier not found. Available: %s" % 
              list(Siamese.objects.all().values_list('pk', flat=True)))
    try:
        mission = Mission.objects.get(pk=mission_id)
    except:
        raise Exception("Mission not found. Available: %s" % 
              list(Mission.objects.all().values_list('pk', flat=True)))

    print(f"Classifier: {clf}")
    print(f"Mission: {mission}")

    from analysis.classifiers.siamese import SiameseClassifierONNX

    df_file_paths = []
    
    if not os.path.exists(clf.model_path_onnx):
        clf.create_onnx_model()

    ref_df = clf._get_reference_spectra()
    logger.info(f"Siamese classifier prepared with references: {list(ref_df.label)}")
    cclf = SiameseClassifierONNX(
        clf, ref_df)

    idle_timeout = 10

    def yield_cached_datasets():
        page_index = 0
        time_last_page = timezone.now()
        while True:
            if not cache.get(f'datapage_ready_{page_index}'):
                time.sleep(0.1)
                logger.info("Sleeping for page ready")
                seconds_since = (
                    timezone.now() - time_last_page
                ).total_seconds()
                if seconds_since > idle_timeout:
                    raise TimeoutError("No scans in {idle_timeout}s")
                continue
            time_last_page = timezone.now()

            logger.info(f"Retrieving page: {page_index}")
            df = cache.get(
                f'datapage_{page_index}'
            )
            cache.set(f'datapage_ready_{page_index}', False)
            page_index = (page_index + 1) % PAGE_SIZE
            yield df

    logger.info("Preparing datafeeder")
    data_feed = ScanDataPrep(clf, mission, chunk_size=500)
    data_feed.start()
    time.sleep(1)

    for idx, scan_df in enumerate(yield_cached_datasets()):
        logger.info("Initializing Classifier")
        tstart = time.time()
        pred_df = cclf.classify_scans(scan_df)
        file_part_path = clf.result_path(mission_id, part=f"-{idx}")
        cache.set("rt_classify_time", time.time() - tstart)
        cclf.create_result_df(pred_df, file_part_path)
        cache.set("rt_classify_save_time", time.time() - tstart)
        cache.set("rt_classify_size", len(pred_df))
        cache.set("rt_classify_lastfile", file_part_path)
        df_file_paths.append(file_part_path)
    
    result_df = pd.concat((
        pd.read_csv(f) for f in df_file_paths), ignore_index=True)
    result_df.to_csv(clf.result_path(mission_id))


if __name__ == '__main__':
    main()
