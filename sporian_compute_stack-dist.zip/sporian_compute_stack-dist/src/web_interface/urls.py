##
# © Copyright 2023 Spectrabotics <spectrabotics.com>
##

from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("materials", views.materials, name="materials"),
    path("material_compare", views.material_compare, name="material_compare"),
    path("render_result", views.render_result, name="render_result"),
    
    path("render_result_pointdata/<int:clf_id>/<int:scan_id>",
         views.render_result_pointdata, name="render_result_pointdata"),
    
    path("enable_sys/<str:service>", views.enable_sys, name="enable"),
    path("disable_sys/<str:service>", views.disable_sys, name="disable"),

    path("mavlink/status", views.mavlink_status, name="status_mavlink"),
    path("camera/status", views.camera_status, name="status_camera"),
    path("sporian/status", views.sporian_status, name="status_sporian"),
    
    path("sporian_render", views.sporian_render, name="sporian_render"),
    path("render_scan_pointdata/<int:scan_id>",
         views.render_scan_pointdata, name="render_scan_pointdata"),
    
    path("sporian_target", views.sporian_target, name="sporian_target"),
    path("update_target", views.update_target, name="update_target"),
    path("sporian/set_mode/<str:mode>", views.sporian_set_mode, name="sporian_set_mode"),
    path("system_logs", views.system_logs, name="system_logs"),
    path("set_mission", views.set_mission, name="set_mission"),
]