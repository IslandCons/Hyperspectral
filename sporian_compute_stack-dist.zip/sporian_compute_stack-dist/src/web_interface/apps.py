import logging

from django.apps import AppConfig

logger = logging.getLogger("compute_node.%s" % __name__)


class WebConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "web_interface"

    def ready(self):
        pass