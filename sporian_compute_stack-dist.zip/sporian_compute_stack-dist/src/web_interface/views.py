##
# © Copyright 2023 Spectrabotics <spectrabotics.com>
##

import os
import logging
import random
import docker
import numpy as np
import plotly.graph_objects as go

from django.http import HttpResponse, JsonResponse
from datetime import datetime
from django.utils.timezone import make_aware

from django.shortcuts import render
from analysis.models import Material
from drone.models import MavlinkPacket, CameraImage, Mission
from sporian.models import Scan
from compute_node.tasks import handle_task_toggle
from sporian.sensor_reader import HSIo
from plotly.io import to_html
from sporian.render import create_scan_map, create_scan_sweep, color_image_df
from analysis.util import normalize
from analysis.models import Classifier, Siamese
from analysis import result_render as analysis_view
from django.db.models import Min, Max
from web_interface.util import wavelength_to_rgb

logger = logging.getLogger("compute_node.%s" % __name__)


def index(request):
    context = {}
    return render(request, "index.html", context)


def materials(request):
    context = {
        "materials": Material.objects.all()
    }
    if request.method =='POST':
        mat_pk = request.POST.get("mat_pk_select")
        if mat_pk:
            material = Material.objects.get(pk=mat_pk)
            render_sample = int(request.POST.get("sample_render_count", 50))
            plot = material.build_plot(sample_count=render_sample)
            context['material'] = material
            context['material_plot'] = plot
    return render(request, "materials.html", context)


def material_compare(request, sample_count=50):
    traces = []
    mat_scans = {}

    def calculate_x_ticks(data_length):
        # Equation: -.0005x^2+3.4841x+330.38
        x_values = np.linspace(0, data_length - 1, data_length)
        return -0.0005 * x_values**2 + 3.4841 * x_values + 330.38

    for material in Material.objects.all():
        scan_sample = material.scans.order_by("?")[:sample_count]
        vis_data = normalize([
            # scan.ir_data
            scan.vis_data
            for scan in scan_sample
        ])
        vis_data = np.median(vis_data, axis=0)
        mat_scans[f'ID ({material.pk}): {material.material_id}'] = vis_data
    
    # Calculate X-axis ticks based on the length of data
    x_ticks = calculate_x_ticks(len(vis_data))
    
    for label, data in mat_scans.items():
        traces.append(
            go.Scatter(
                x=x_ticks, y=data,
                mode='lines', name=label
            )
        )

    # Number of evenly spaced intervals
    N_intervals = 15  # Adjust as needed
    # Calculate N evenly spaced intervals along x_ticks
    x_intervals = np.linspace(np.min(x_ticks), np.max(x_ticks), N_intervals)
    # Calculate RGB colors at each interval
    interval_colors = [wavelength_to_rgb(wavelength) for wavelength in x_intervals]

    layout_shapes = []
    layout_annotations = []

    for i, tick in enumerate(x_intervals):
        layout_shapes.append(dict(
            type="line",
            xref="x", yref="paper",
            x0=tick, y0=0,
            x1=tick, y1=1,
            line=dict(
                color=f'rgb({int(interval_colors[i][0]*255)}, {int(interval_colors[i][1]*255)}, {int(interval_colors[i][2]*255)})',
                width=2
            )
        ))
        layout_annotations.append(dict(
            x=tick,
            y=-0.05,  # Adjust the y-coordinate of the annotation
            xref='x', yref='paper',
            text=f'{tick:.1f}',  # Display one decimal place
            showarrow=False,
            font=dict(
                family="Arial",
                size=12,
                color="black"
            ),
        ))


    layout = go.Layout(
        title='Material Samples',
        xaxis=dict(title='Wavelength'),
        yaxis=dict(title='Normalized Intensity'),
        plot_bgcolor='rgb(255,255,255)',  # Set background color to white
        shapes=layout_shapes, annotations=layout_annotations
    )
    
    # Create the figure with traces and layout
    fig = go.Figure(data=traces, layout=layout)
    context = {
        "plot": to_html(fig, full_html=False, include_plotlyjs=False)
    }
    return render(request, "material_compare.html", context)


def enable_sys(request, service):
    logger.info(f"Enabling service: {service}")
    task_state = handle_task_toggle(service, True)
    return render(request, "htmx/task_state.html", {"task": task_state})


def disable_sys(request, service):
    logger.info(f"Disabling service: {service}")
    task_state = handle_task_toggle(service, False)
    return render(request, "htmx/task_state.html", {"task": task_state})


def mavlink_status(request):
    count = MavlinkPacket.objects.count()
    try:
        packet = MavlinkPacket.objects.latest("pk")
    except:
        packet = None
    return render(request, "htmx/mavlink_status.html", {
        "packet": packet, "count": count
    })


def camera_status(request):
    count = CameraImage.objects.count()
    try:
        cam_img = CameraImage.objects.latest("pk")
    except:
        cam_img = None
    return render(request, "htmx/camera_status.html", {
        "cam_img": cam_img, "count": count
    })


def sporian_status(request):
    count = Scan.objects.count()
    try:
        scan = Scan.objects.latest("scanNum")
    except:
        scan = None
    return render(request, "htmx/sporian_status.html", {
        "scan": scan, "count": count
    })


def system_logs(request):
    client = docker.from_env()

    container_id = request.GET.get("container_id", 'internal')

    log_kwargs = {}
    for k in ['since']:
        if k in request.GET.keys():
            log_kwargs[k] = int(request.GET.get(k))

    def get_container_by_substring(substring):
        for cont in client.containers.list():
            if substring in cont.name:
                return cont
    
    try:
        container = get_container_by_substring(container_id)
        logs = container.logs(**log_kwargs).decode('utf-8')
    except docker.errors.NotFound:
        return HttpResponse('Container not found', status=404)

    response = HttpResponse(logs, content_type='text/plain')
    return response


def set_mission(request):
    if request.method =='POST':
        mission_id = request.POST.get("mission_id")
        if mission_id:
            Mission.objects.create(mission_id=mission_id)
    context = {
        "latest_mission": Mission.objects.latest('pk')
    }
    return render(request, "htmx/mission.html", context)


def sporian_set_mode(request, mode, address=os.environ['SENSOR_ADDR']):
    assert mode in ['pause', 'resume']
    logger.info(f"Setting sensor mode: {mode}")
    ip, port = address.split(":")
    hsi = HSIo(ip, int(port))
    res = hsi.sweep_pause(mode)
    logger.info(f"Set sensor mode, res={res} (0 sweeping, 1 pause)")
    return render(request, "htmx/sensor_stare_state.html", {"res": res})


def sporian_target(request, num=1500):
    instances = Scan.objects.all().order_by('-scanNum')[:num]
    instances = instances[::10][:100]
    df = color_image_df(instances)
    df.galvo_pos = (df.galvo_pos / 100).astype('int')
    scan_sweep = create_scan_sweep(df)
    vis_plot = to_html(
        scan_sweep, full_html=False,
        include_plotlyjs=False, div_id='plot'
    )
    context = {
        "scans": instances,
        "scan_sweep": vis_plot
    }
    return render(request, "sporian_target.html", context)


def update_target(request, num=1500):
    #    r = random.randint(20000,500000)
    r = 0
    instances = Scan.objects.all().order_by('-scanNum')[r:r+num]
    instances = instances[::10][:100]
    df = color_image_df(instances)
    df.galvo_pos = (df.galvo_pos / 100).astype('int')
    df.drop_duplicates(subset=['galvo_pos'], inplace=True)
    # json_data = df.to_json(orient='records')
    json_data = {
        "color": list(df.color),
        "galvo_pos": list(df.galvo_pos),
        "max_vis": list(df.max_vis),
    }
    # Return the JSON response
    return JsonResponse(json_data, safe=False)


def sporian_render(request):
    mission_id = None
    scan_instances = None
    earliest_timestamp = None
    latest_timestamp = None
    count = 50
    first_scan, last_scan, scan_map, vis_plot = None, None, None, None

    if request.method =='POST':
        mission_id = int(request.POST.get("mission_id"))
        scans = Scan.objects.filter(mission_id=mission_id)
        count = int(request.POST.get("slider"))
        dtimes = [
            request.POST.get(dk)
            for dk in ["timeoffset1", "timeoffset2"]
        ]
        if '' not in dtimes:
            dtimes = [int(dt) for dt in dtimes]
            earliest_timestamp = min(dtimes)
            latest_timestamp = max(dtimes)
        else:
            earliest_timestamp = scans.earliest('timeStamp').timeStamp
            latest_timestamp = scans.latest('timeStamp').timeStamp
        scan_instances = scans.filter(
            timeStamp__gte=earliest_timestamp,
            timeStamp__lte=latest_timestamp,
        )
        logger.info(f"Scan count: {len(scan_instances)}")
        scan_samples = scan_instances.order_by('?')[:count]
        # Extract useful materials
        scannums = scan_instances.aggregate(
            smallest=Min('scanNum'), largest=Max('scanNum'))
        materials = Material.objects.filter(
            scanNum_start__gt=scannums['smallest'],
            scanNum_end__lt=scannums['largest'],
        )
        scan_map = create_scan_map(scan_samples, materials)
        vis_plot = to_html(
            scan_map, full_html=False, include_plotlyjs=False,
            div_id="sporian_plot")
        first_scan = scan_instances.first()
        last_scan = scan_instances.last()
    
    context = {
        "scans": scan_instances,
        "mission_id": mission_id,
        "missions": Mission.objects.all().order_by('pk'),
        "earliest_timestamp": earliest_timestamp,
        "latest_timestamp": latest_timestamp,
        "first": first_scan,
        "last": last_scan,
        "scan_count": count,
        "scan_map": vis_plot
    }
    return render(request, "sporian_render.html", context)


def render_scan_pointdata(request, scan_id):
    scan = Scan.objects.filter(scanNum__gt=scan_id).earliest('scanNum')
    fig, fig_norm = analysis_view.render_scan_figures(scan)
    context = {
        "scan": scan,
        'scan_fig_norm': to_html(
            fig_norm, full_html=False, include_plotlyjs=False, div_id="scan_fig_norm"
        ),
    }
    return render(request, "result_render_point.html", context)


def render_result(request):
    context = {
        "missions": Mission.objects.all().order_by('pk'),
        "classifiers": Classifier.objects.all().order_by('pk')
    }
    if request.method =='POST':
        mission_pk = request.POST.get("mission_id")
        classifier_pk = request.POST.get("classifier_id")
        if mission_pk and classifier_pk:
            context['mission_id'] = int(mission_pk)
            context['classifier_id'] = int(classifier_pk)
            try:
                scatter_fig = analysis_view.load_scatter(mission_pk, classifier_pk)
                context['scatter_fig'] = to_html(
                    scatter_fig, full_html=False, include_plotlyjs=False,
                    div_id="result_scatter")
            except Exception as e:
                logger.exception("Failed to load result")
                context['scatter_error'] = str(e)

    return render(request, "result_render.html", context)


def realtime_render(request):
    context = {
        "missions": Mission.objects.all().order_by('pk'),
        "classifiers": Siamese.objects.all().order_by('pk')
    }
    if request.method =='POST':
        mission_pk = request.POST.get("mission_id")
        classifier_pk = request.POST.get("classifier_id")
        if mission_pk and classifier_pk:
            context['mission_id'] = int(mission_pk)
            context['classifier_id'] = int(classifier_pk)
            
            from analysis.tasks import realtime_analysis
            realtime_analysis.delay(classifier_pk, mission_pk)

    return render(request, "realtime_render.html", context)


def render_result_pointdata(request, clf_id, scan_id):
    clf = Classifier.objects.get(pk=clf_id)
    scan = Scan.objects.filter(scanNum__gt=scan_id).earliest('scanNum')
    material = request.GET.get("material")
    fig, fig_norm = analysis_view.render_scan_figures_refs(
        clf, scan, material_name=material)
    try:
        cam_img = CameraImage.objects.filter(
            mission=scan.mission,
            relative_time__lt=scan.relative_time).latest('relative_time')
    except:
        cam_img = None
    context = {
        "scan": scan,
        'scan_fig': to_html(
            fig, full_html=False, include_plotlyjs=False, div_id="scan_fig"
        ),
        'cam_img': cam_img,
        'scan_fig_norm': to_html(
            fig_norm, full_html=False, include_plotlyjs=False, div_id="scan_fig_norm"
        ),
    }
    return render(request, "result_render_point.html", context)