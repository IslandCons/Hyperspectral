import cv2
import time
import logging
from pymavlink import mavutil
import time


class MavlinkRead(object):
    """A class to setup a mavlink connection"""
    latest_mav_data = {}
    drone_link = None

    def __init__(self, mavlink_address, **kwargs):
        self.log = logging.getLogger(self.__class__.__name__)
        # Now create drone_link instance
        self._init_drone_link(mavlink_address)
        # Configure AHRS2 message to be sent at 1Hz
        self.request_message_interval(
            mavutil.mavlink.MAVLINK_MSG_ID_AHRS2, 1)
        # Configure ATTITUDE message to be sent at 2Hz
        self.request_message_interval(
            mavutil.mavlink.MAVLINK_MSG_ID_ATTITUDE, 2)
        # Configure GPS message to be sent at 1Hz
        self.request_message_interval(
            mavutil.mavlink.MAVLINK_MSG_ID_GPS_RAW_INT, 1)
        # Configure BATT message to be sent at 1Hz
        self.request_message_interval(
            mavutil.mavlink.MAVLINK_MSG_ID_BATTERY_STATUS, 1)

    def _init_drone_link(self, mavlink_address):
        while self.drone_link == None:
            try:
                self.log.info(f"Attempting to connect to ({mavlink_address})")
                self.drone_link = mavutil.mavlink_connection(mavlink_address)
                self.log.info(f"Waiting for heartbeat..")
                self.drone_link.wait_heartbeat()
                self.log.info(
                    "Heartbeat received (system %u component %u)" % (
                        self.drone_link.target_system,
                        self.drone_link.target_component
                    )
                )
            except:
                self.log.exception("Exception connecting to mavlink. Waiting")
                time.sleep(5)
        
    def request_message_interval(self, message_id: int, frequency_hz: float):
        """
        Request MAVLink message in a desired frequency,
        documentation for SET_MESSAGE_INTERVAL:
            https://mavlink.io/en/messages/common.html#MAV_CMD_SET_MESSAGE_INTERVAL

        Args:
            message_id (int): MAVLink message ID
            frequency_hz (float): Desired frequency in Hz
        """
        self.drone_link.mav.command_long_send(
            self.drone_link.target_system,
            self.drone_link.target_component,
            mavutil.mavlink.MAV_CMD_SET_MESSAGE_INTERVAL, 0,
            message_id, # The MAVLink message ID
            1e6 / frequency_hz, # The interval between two messages in microseconds. Set to -1 to disable and 0 to request default rate.
            0, 0, 0, 0, # Unused parameters
            0, # Target address of message stream (if message has target address fields). 0: Flight-stack default (recommended), 1: address of requestor, 2: broadcast.
        )



class CameraRead(object):
    """A class to take periodic camera images"""
    camera = None

    def __init__(self, **kwargs):
        self.log = logging.getLogger(self.__class__.__name__)
        # Now create camera instance
        self._init_camera()
        
    def _init_camera(self, cam_dev_id=0):
        attempts = 0
        while self.camera == None:
            try:
                attempts += 1
                self.log.info(f"Attempting to connect to ({cam_dev_id})")
                self.camera = cv2.VideoCapture(cam_dev_id)
                #codec = 0x47504A4D  # MJPG
                #self.camera.set(cv2.CAP_PROP_FPS, 30.0)
                #self.camera.set(cv2.CAP_PROP_FOURCC, codec)
                #self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
                #self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
            except:
                if attempts > 10:
                    raise
                self.log.exception("Exception connecting to camera. Waiting")
                time.sleep(1)

    def get_image(self):
        success, img = self.camera.read()
        if success:
            return img
