import logging
from django.contrib import admin
from .models import MavlinkPacket, CameraImage, Mission

logger = logging.getLogger(f"compute_node.{__name__}")


@admin.register(MavlinkPacket)
class MavlinkPacketAdmin(admin.ModelAdmin):
    list_display = ("pk", "mission", "relative_time", "type")


@admin.register(CameraImage)
class CameraImageAdmin(admin.ModelAdmin):
    list_display = ("pk", "mission", "relative_time",)


@admin.register(Mission)
class MissionAdmin(admin.ModelAdmin):
    list_display = ("pk", "mission_id", "timestamp",)
