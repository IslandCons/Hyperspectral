import logging
from django.db import models

logger = logging.getLogger(f"compute_node.{__name__}")


class Mission(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    mission_id = models.CharField(max_length=128, unique=True)

    class Meta:
        ordering = ['-timestamp']

    @property 
    def first_scan(self):
        return self.scan_set.earliest('scanNum')


class MavlinkPacket(models.Model):
    mission = models.ForeignKey(Mission, on_delete=models.CASCADE)
    
    type = models.CharField(max_length=64)
    data = models.JSONField()
    relative_time = models.IntegerField()

    class Meta:
        ordering = ['mission', '-relative_time']


class CameraImage(models.Model):
    mission = models.ForeignKey(Mission, on_delete=models.CASCADE)
    
    relative_time = models.IntegerField()
    image = models.ImageField(upload_to ='camera/')

    class Meta:
        ordering = ['mission', '-relative_time']

