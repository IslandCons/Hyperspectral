import os
import time
from celery.utils.log import get_task_logger
from compute_node.celery import app, redis_task_lock
from .drone_reader import MavlinkRead, CameraRead
from .models import MavlinkPacket, CameraImage
from celery.result import AsyncResult
from django.core.cache import cache
from django.conf import settings
from django.core.files import File
from django.utils import timezone
from datetime import datetime
import cv2

logger = get_task_logger(f"compute_node.{__name__}")


@app.task(bind=True, soft_timeout=30*60)
def read_mavlink(self, lock_id):
    from drone.models import Mission
    with redis_task_lock(lock_id, self.request.id) as acquired:
        if not acquired:
            logger.error("Cannot run parallel collections")
            return AsyncResult(cache.get(lock_id))
        logger.info("Obtained lock, running collection")
        mavlink_address = os.environ['MAVLINK_ADDR']
        mavlink_reader = MavlinkRead(mavlink_address)
        latest_mission = Mission.objects.latest('pk')
        mission_time = latest_mission.timestamp
        logger.info("Starting drone read loop")


        check_counter = 0
        while True:
            # Check if we need to break while loop
            check_counter += 1
            if check_counter > 100:
                check_counter = 0
                if not cache.get(lock_id):
                    raise ConnectionAbortedError("Exiting collection")
            try:
                data = mavlink_reader.drone_link.recv_match(blocking=True)
                if not data:
                    continue
                data = data.to_dict()
                mavpack = MavlinkPacket.objects.create(
                    type=data.get('mavpackettype', 'NA'),
                    data=data, mission=latest_mission,
                    relative_time=(timezone.now() - mission_time).total_seconds()
                )
                logger.info(f"Saved Mavlink Packet: {mavpack.pk}")
            except:
                logger.exception("Unexpected exception reading data")
                time.sleep(0.1)


@app.task(bind=True, soft_timeout=30*60)
def read_camera(self, lock_id):
    from drone.models import Mission
    with redis_task_lock(lock_id, self.request.id) as acquired:
        if not acquired:
            logger.error("Cannot run parallel collections")
            return
        logger.info("Obtained lock, running collection")

        camera_reader = CameraRead()
        latest_mission = Mission.objects.latest('pk')
        mission_time = latest_mission.timestamp
        logger.info("Starting camera read loop")
        
        check_counter = 0
        while True:
            # Check if we need to break while loop
            check_counter += 1
            if check_counter > 3:
                check_counter = 0
                if not cache.get(lock_id):
                    raise ConnectionAbortedError("Exiting collection")
            try:
                img = camera_reader.get_image()
                if img is not None:
                    # Create a filename using the timestamp
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"camera_{timestamp}.jpg"
                    cam_img = CameraImage(
                        mission=latest_mission,
                        relative_time=(timezone.now() - mission_time).total_seconds()
                    )
                    cv2.imwrite("temp.jpg", img)
                    cam_img.image.save(
                        filename, 
                        File(open("temp.jpg", 'rb')),
                        save=True)
                    logger.info(f"Saved: {filename}")
                else:
                    logger.warning("Issue taking photo")
            except:
                logger.exception("Unexpected exception reading camera")
            time.sleep(settings.CAMERA_INTERVAL)
