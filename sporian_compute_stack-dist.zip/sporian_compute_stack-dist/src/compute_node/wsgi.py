"""
WSGI config for compute_node project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.2/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'compute_node.settings')

from django.conf import settings
if settings.DEBUG:
    import debugpy
    debugpy.listen(('0.0.0.0', 3000))

application = get_wsgi_application()

