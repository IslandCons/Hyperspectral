from celery.utils.log import get_task_logger
from django.core.cache import cache
from celery.result import AsyncResult
from drone import tasks as drone_tasks
from sporian import tasks as sporian_tasks
from compute_node.celery import app, redis_task_lock
import time
from django.utils import timezone
from drone.models import Mission
import subprocess
logger = get_task_logger(f"compute_node.{__name__}")


try:
    import Jetson.GPIO as GPIO
except:
    logger.exception("Failed to set GPIO mode - ignore if no GPIO")


@app.task(bind=True, soft_timeout=30*60)
def toggle_collection(self, lock_id='toggle_monitor'):
    # https://developer.nvidia.com/embedded/learn/jetson-orin-nano-devkit-user-guide/hardware_spec.html
    BUT_PIN = 7
    LED_WARN = 29
    LED_FAIL = 31
    LED_WORK = 33
    LED_OK = 32
    LED_PINS = [LED_WARN, LED_FAIL, LED_OK, LED_WORK]
    try:
        GPIO.setmode(GPIO.BOARD)
        time.sleep(1)
        GPIO.setup(BUT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
        time.sleep(1)
        GPIO.setup(LED_PINS, GPIO.OUT)
    except NameError:
        logger.exception("GPIO not imported! May need install")
        return
    toggle_state = False

    with redis_task_lock(lock_id, self.request.id) as acquired:
        if not acquired:
            logger.error("Cannot run parallel toggle")
            return AsyncResult(cache.get(lock_id))
        logger.info("Obtained lock, running collection")
        
        try:
            while True:
                logger.info("Setting up LED pins")
                for lp in LED_PINS:
                    GPIO.output(lp, 0)
                if toggle_state:
                    GPIO.output(LED_OK, 1)
                else:
                    GPIO.output(LED_FAIL, 1)

                logger.info("Waiting for button event")
                GPIO.wait_for_edge(BUT_PIN, GPIO.RISING)
                
                # event received when button pressed
                logger.info("Button Pressed!")
                mission_count = Mission.objects.count()
                Mission.objects.create(
                    mission_id=f"ButtonPress_{mission_count}")

                for lp in LED_PINS:
                    GPIO.output(lp, 1)
                toggle_state = not toggle_state

                for component in ['camera', 'mavlink', 'sporian']:
                    logger.info(f"Toggling {component} (enable:{toggle_state})")
                    handle_task_toggle(component, toggle_state)
                    if toggle_state == False:
                        logger.info("Shutting down!")
                        shutdown() # Shutdown device
                
                time.sleep(1)
        finally:
            GPIO.cleanup()  # cleanup all GPIOs


def call_or_get_task(task):
    lock_id = task.__name__
    existing_task_id = cache.get(lock_id)
    logger.info(f"Existing task?: {existing_task_id}")
    if existing_task_id:
        task_state = AsyncResult(existing_task_id)
        logger.info(f"Existing task state: {task_state.status}")
        if not task_state.ready():
            return task_state
    else:
        logger.info(f"Running fresh task")
        async_result = task.apply_async(kwargs={"lock_id": lock_id})
        return async_result


def revoke_task(task):
    lock_id = task.__name__
    logger.info(f"Attempting revoke: {lock_id}")
    existing_task_id = cache.get(lock_id)
    try:
        if existing_task_id:
            logger.info(f"Clearing cache lock: {lock_id}")
            cache.delete(lock_id)
            logger.info(f"Revoking Task ID: {existing_task_id}")
            task_state = AsyncResult(existing_task_id)
            task_state.revoke()
            return AsyncResult(existing_task_id)
        else:
            logger.error(f"For some reason, no task ID for lock: {lock_id}")
            return 
    except:
        logger.exception("Issue in revoke")


def handle_task_toggle(service, task_enable):
    if task_enable:
        operation = call_or_get_task
    else:
        operation = revoke_task
    # Now fetch the service
    if service == 'camera':
        tasks = [drone_tasks.read_camera]
    elif service == 'mavlink':
        tasks = [drone_tasks.read_mavlink]
    elif service == 'sporian':
        tasks = [sporian_tasks.read_sensor, sporian_tasks.parse_scans]
    else:
        raise Exception(f"Unhandled service: {service}")
    for task in tasks:
        logger.info(f"Revoking task: {task}")
        task_result = operation(task)
    if task_result:
        logger.info(f"Task: {task_result} {task_result.state}")
    else:
        logger.info("No task returned")
    time.sleep(1)
    return task_result


def shutdown():
    command = "ssh -o 'StrictHostKeyChecking no' root@172.17.0.1 shutdown -P"
    logger.info("Attempting shutdown")
    # Run the command
    result = subprocess.run(command, shell=True, capture_output=True, text=True)

    # Check the result
    if result.returncode == 0:
        logger.info("Command executed successfully.")
    else:
        logger.info("Error executing command.")
        logger.info("Error message:")
        logger.error(result.stderr)
