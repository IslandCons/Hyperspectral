import os 
from django.apps import AppConfig



class ComputeNodeAppConfig(AppConfig):
    name = 'compute_node'

    def ready(self):
        from .tasks import toggle_collection
        toggle_collection.apply_async() # start the toggle on boot