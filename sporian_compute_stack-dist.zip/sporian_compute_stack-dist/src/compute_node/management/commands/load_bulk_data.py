import os
import ijson
import decimal
from django.apps import apps
from base64 import b64decode
from django.core.management.base import BaseCommand


def find_fixture_path(fixture_name):
    # Iterate through all installed apps
    for app_config in apps.get_app_configs():
        # Get the path to the fixtures directory for the app
        fixtures_path = os.path.join(app_config.path, 'fixtures')
        # Check if the fixture file exists in the fixtures directory
        fixture_file_path = os.path.join(fixtures_path, f'{fixture_name}.json')
        if os.path.exists(fixture_file_path):
            return fixture_file_path
    return None


class Command(BaseCommand):
    help = 'Ingest massive fixtures using bulk_create'

    def add_arguments(self, parser):
        parser.add_argument('fixture_file', type=str, help='Path to the fixture file')
    
    def handle(self, *args, **options):
        fixture_file = options['fixture_file']
                
        # Example usage
        fixture_path = find_fixture_path(fixture_file)
        if fixture_path:
            print("Fixture file found:", fixture_path)
        else:
            print("Fixture file not found.")
        unprocessed_fixtures = []
            
        # Define a generator to yield data items from the JSON file incrementally
        def read_fixture_data(file_path):
            with open(file_path, 'rb') as f:
                items = ijson.items(f, "item")
                for item in items:
                    if 'visData' in item['fields']:
                        for df in ['visData', 'irData']:
                            item['fields'][df] = b64decode(
                                item['fields'][df].encode('utf-8')
                            )
                    if 'data' in item['fields']:
                        for k, v in item['fields']['data'].items():
                            if type(v) == decimal.Decimal:
                                item['fields']['data'][k] = float(v)
                    yield item
    
        # Split the data into chunks of 1000 records
        chunk_size = 100
        chunk_buffer = {}
        ingested_count = {}

        def count_up(mod_str, count):
            if mod_str not in ingested_count.keys():
                ingested_count[mod_str] = 0
            print(f"Created {count} {mod_str}")
            ingested_count[mod_str] += count

        def create_records(mod_str, cm_buff, unprocessed_fixtures):
            model_cls = apps.get_model(mod_str)
            try:
                records = []
                print(f"Creating {len(cm_buff)} {model_cls} records")
                for data in cm_buff:
                    if 'mission' in data['fields']:
                        data['fields']['mission_id'] = data['fields']['mission']
                        del data['fields']['mission']
                    records.append(
                        model_cls(**data['fields'])
                    ) 
                print(f"Bulk inserting {len(records)}")
                model_cls.objects.bulk_create(records, ignore_conflicts=True)
                count_up(mod_str, len(cm_buff)) 
            except Exception as e:
                print(f"Error {e} while ingesting data like: {cm_buff[0]}")
                unprocessed_fixtures += cm_buff
                print("Saving failed data to unprocessed fixture")
            return unprocessed_fixtures

        for item in read_fixture_data(fixture_path):
            mod_str = item['model']
            if mod_str not in chunk_buffer.keys():
                chunk_buffer[mod_str] = []
            cm_buff = chunk_buffer[mod_str]
            cm_buff.append(item)
            if len(cm_buff) == chunk_size:
                unprocessed_fixtures = create_records(
                    mod_str, cm_buff, unprocessed_fixtures)
                chunk_buffer[mod_str] = []

        # In case there are any remaining items in the buffer
        for mod_str, cm_buff in chunk_buffer.items():
            unprocessed_fixtures = create_records(
                mod_str, cm_buff, unprocessed_fixtures)

        if unprocessed_fixtures:
            import simplejson as json
            with open(f"{fixture_path}.unprocessed.json", "w") as f:
                json.dump(
                    unprocessed_fixtures,
                    f, indent=2
                )

        self.stdout.write(self.style.SUCCESS(
            f'Successfully ingested the fixture data: {ingested_count}'
        ))
