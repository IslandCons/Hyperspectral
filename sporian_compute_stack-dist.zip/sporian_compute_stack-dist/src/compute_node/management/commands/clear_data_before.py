from django.core.management.base import BaseCommand


class ProxyModelWarning(Warning):
    pass


class Command(BaseCommand):
    help = (
        "Delete all objects relevant to sporian analysis before a time."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "end_time",
            help=(
                "Time Range to delete before."
            ),
        )

    def handle(self, end_time, **options):
        from drone.models import MavlinkPacket, CameraImage
        from sporian.models import Scan
        from analysis.models import Classification
        for cls in [MavlinkPacket, CameraImage, Scan, Classification]:
            dcount = cls.objects.filter(timestamp__lt=max(end_time)).delete()
            print(f"Deleted {cls} count: {dcount}")
         