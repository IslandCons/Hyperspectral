﻿##
# © Copyright 2021 Spectrabotics
##

from __future__ import absolute_import

import os
import logging
from contextlib import contextmanager

from celery import Celery
from django.core.cache import cache

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "compute_node.settings")

logger = logging.getLogger("alludium.%s" % __name__)

REDIS_HOST = os.environ["REDIS_HOST"]
REDIS_PORT = os.environ["REDIS_PORT"]

celery_broker_url = "redis://%s:%s/1" % (REDIS_HOST, REDIS_PORT)
celery_backend_url = "redis://%s:%s/2" % (REDIS_HOST, REDIS_PORT)
broker_url = "%s" % (celery_broker_url)
backend_url = "%s" % (celery_backend_url)

app = Celery("compute_node", broker=broker_url, backend=backend_url)
app.config_from_object("compute_node.settings", namespace="CELERY")
app.conf.task_default_queue = 'global'
app.autodiscover_tasks()



@contextmanager
def redis_task_lock(lock_id, task_id):
    logger.info(f"Creating task lock for {lock_id}, {task_id}")
    status = cache.add(lock_id, task_id)
    try:
        yield status
    finally:
        logger.info("Ending task")
        if status:
            cache.delete(lock_id)
