# sporian_compute

Compute stack for the Hyperspectral Compute Stack mounted to UAV.
Refer to Jetson Nano setup for notes regarding a fresh setup of a Jetson Orin Nano running R36.
Refer to the compute node deployment for running the compute node stack.
This Jetson device is setup using a dedicated NVME as its root drive.

## Architecture

https://docs.google.com/drawings/d/1JKY5f9m12WFefgM1EyAM2XfBfUZwfTqYWfsu2vTa3Xw/

https://docs.google.com/drawings/d/1SZnWdqLMipYrAFBxxSRO4oo7Lb6W3fdLW1C2_3zZH8k/edit

## Jetson First-time set up notes
 
* Jetson Stats
	 * Installed this to help get version info etc
	 * https://github.com/rbonghi/jetson_stats

### Disk Benchmarking

* Navigate to a folder on the volume you want to benchmark, then run the fio command
* `cd /data`
* `fio --name TEST --eta-newline=5s --filename=temp.file --rw=read --size=2g --io_size=10g --blocksize=1024k --ioengine=libaio --fsync=10000 --iodepth=32 --direct=1 --numjobs=1 --runtime=60 --group_reporting`

#### Dan Results:

Run status group 0 (all jobs):
   READ: bw=2337MiB/s (2450MB/s), 2337MiB/s-2337MiB/s (2450MB/s-2450MB/s), io=10.0GiB (10.7GB), run=4382-4382msec

Disk stats (read/write):
  nvme0n1: ios=39883/33, merge=0/12, ticks=527344/77, in_queue=527427, util=98.07%

# Compute Node Guide

To run this code we use Docker and 'Docker compose' (built in to Docker now), so you should be familiar with both before continuing (e.g. running a container, viewing its logs, checking what is running)

### Docker stack startup

Refer to the `docker-compose.yml` file to understand how containers are being deployed

0. Pre-requisites:
	* You have setup Docker
	* You have a large volume available at /data
 1. Clone this repo on to the Jetson Nano
 2. Navigate to the deployed folder (you should be in a folder with `docker-compose.yml`)
 3. Run `sudo docker compose up -d --build`
	 * This will take some time
	 * It should complete successfully 
 4. Check the status of the running containers `sudo docker compose ps`
	 * You should see all/most running (Up) - Flower and Web containers might be stopped but that's okay

After all this, here is what we have:
* A **container image** built called `spectrabotics:sporian_stack_node` which contains all required software versions and packages ready to go.
* `db` PostgreSQL DB for ARM 64
* `nginx` Frontend web server
* `django_wsgi` Web application for the compute node interface
* `internal` Internal worker for long running tasks (data acquisition/classification etc) 
* `jupyter` Interactive development environment 
* `redis_int` A memory cache we use for exchanging data quickly

### ML model preparation

To train the Siamese network open the Notebook: http://localhost:18888/notebooks/Notebook/Siamese.ipynb
In the 4th cell, adjust the PK of the model you wish to train
You can build a model using this notebook, which will train it on the materials assigned to the model. It can then be transferred to the Jetson Node by copying the /data/analysis_model* folder as needed.
The Jetson node will convert it to an ONNX runtime as required.

### Setting up GPIO (LED outputs)

Follow https://github.com/NVIDIA/jetson-gpio

# Startup

## GPIO Wiring

<!-- * LED OK: 37
* LED WARN: 33
* LED FAIL: 35
* LED WORK: 31
* HW toggle Switch: 26 -->

BUT_PIN = 7
LED_WARN = 29
LED_FAIL = 31
LED_WORK = 33
LED_OK = 32

These wires are used more for R&D rather than expected use.
The LEDs should be used to indicate different operations on the device, but at this time they are all used to indicate recording in conjunction with a hardware toggle switch which is used to start/stop recording. 

## Saving/Loading big fixtures

To save, if you're saving a mission of data capture (GPS/Camera/Sporian Scans) use the dump_data_mission command.

To load the data, use the load_bulk_data command - it's hacky but works
`docker-compose -f docker-compose-local.yml exec django_wsgi python3 manage.py load_bulk_data archive_2024-02-10_2024-02-11`

Also, ensure you transfer the relevant scans from the /data/scan_archives and all camera images from /data/media.


## Realtime analysis demonstration

A script is available in ./src/real_time/realtime.py
Use it by getting in to the 'internal' container with the docker compose stack running by using `docker compose exec internal bash`
Once inside, `cd ./real_time`
Then run the realtime.py script with two arguments: the PK of the siamese model and the PK of the mission to analyze, like `python3 realtime.py 10 35`

# Deploying on Desktop

To deploy this software stack in 'groundstation' mode, follow the steps in 'deploy docker stack'
But specify a file with any steps involving 'docker compose' like follows
`docker compose -f docker-compose-ground.yml`
So step 3 would become 
 3. Run `sudo docker compose -f docker-compose-ground.yml up -d --build`

This uses a variation of the Dockerfile which is designed for X86 architecture CPUs - normally the case. Otherwise, the performance is much slower as it must emulate the ARM CPU architecture.