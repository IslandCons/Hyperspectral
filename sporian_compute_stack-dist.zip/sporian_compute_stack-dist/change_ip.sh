#!/bin/bash

echo "Changing the Wired LAN IP address to 192.168.90.111."
sudo ip addr add 192.168.90.111/24 dev eth0
sleep 5
ifconfig eth0

# Run your command and store the output
output=$(python3 /home/spectrabotics/sporian_compute_stack/src/sporian/hsi_lib/ipctl.py discover)
echo "Discovery output:"
echo $output
# Count the number of lines in the output
num_lines=$(echo "$output" | wc -l)

# Check if there are more than one line
if [ "$num_lines" -gt 1 ]; then
    echo "Maintaining LAN IP address"
else
    echo "Ensuring automatic IP address assignment for Wired LAN."
    sudo nmcli con mod 'Wired connection 1' ipv4.method auto
    echo "Running dhclient."
    sudo dhclient eth0
    echo "Wired LAN set to auto-IP address assignment."
fi

sleep 5
ifconfig eth0