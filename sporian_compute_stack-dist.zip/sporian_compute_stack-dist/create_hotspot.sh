#!/bin/bash
# Define the target Wi-Fi network
target_network="RebaNet24"
# Set hotspot parameters
hotspot_ssid="DroneAP"
hotspot_password="spectrabotics"  # Change this to your desired password

date
nmcli connection down DroneAP
ifconfig wlan0 down
ifconfig wlan0 up
sleep 10

# Check if the target Wi-Fi network is available
echo $(nmcli device wifi list)
if nmcli device wifi list | grep -q "$target_network"; then
    echo "Wi-Fi network '$target_network' found."
else
    echo "Wi-Fi network '$target_network' not found. Creating hotspot 'DroneAP'."

    # Create the hotspot
    nmcli device wifi hotspot con-name "$hotspot_ssid" ssid "$hotspot_ssid" password "$hotspot_password"
    nmcli connection modify "$hotspot_ssid" ipv4.method shared ipv4.address 192.168.1.1/24 ipv4.gateway 192.168.1.254
    # mdns_hostname="drone"
    # avahi-publish -R "$mdns_hostname" _http._tcp 80
    # Check if hotspot creation was successful
    if [ $? -eq 0 ]; then
        echo "Hotspot '$hotspot_ssid' created successfully."
    else
        echo "Error creating hotspot. Please check your network configurations."
    fi
fi
